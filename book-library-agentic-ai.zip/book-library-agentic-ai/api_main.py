#!/usr/bin/env python3
"""
API Server Entry Point
Run this to start the REST API server
"""

from src.api_server import LibraryAPI

if __name__ == '__main__':
    # Create API instance on port 5000
    api = LibraryAPI(port=5000)
    
    # Run the server
    api.run(debug=True)