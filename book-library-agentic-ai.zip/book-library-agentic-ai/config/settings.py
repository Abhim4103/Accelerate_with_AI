import os
from datetime import timedelta

# Database settings
DATABASE_PATH = os.path.join(os.path.dirname(__file__), '..', 'library.db')
DATA_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'data')

# Data file paths
BOOKS_CSV = os.path.join(DATA_FOLDER, 'books.csv')
EMPLOYEES_CSV = os.path.join(DATA_FOLDER, 'employees.csv')
BORROWERS_CSV = os.path.join(DATA_FOLDER, 'borrowers.csv')
PROVIDERS_CSV = os.path.join(DATA_FOLDER, 'providers.csv')

# Borrow settings
DEFAULT_BORROW_DAYS = 14
OVERDUE_REMINDER_DAYS = 2

# AI Agent settings
MAX_TOOL_CALLS = 10
RESPONSE_TIMEOUT = 30

# Logging
LOG_LEVEL = "INFO"
LOG_FILE = os.path.join(os.path.dirname(__file__), '..', 'logs', 'library.log')

# Color settings
USE_COLORS = True