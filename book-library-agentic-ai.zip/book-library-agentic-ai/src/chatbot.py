import json
from src.agentic_ai import AgenticAI
from src.utils import (
    print_header, print_success, print_error, print_info, 
    print_warning, print_table, format_date
)
from tabulate import tabulate

class LibraryChatbot:
    """Interactive chatbot for library management"""
    
    def __init__(self):
        self.agent = AgenticAI()
        self.commands = self._initialize_commands()
    
    def _initialize_commands(self) -> dict:
        """Initialize chatbot commands"""
        return {
            "help": self.show_help,
            "tools": self.list_tools,
            "books": self.show_all_books,
            "available": self.show_available_books,
            "employees": self.show_all_employees,
            "stats": self.show_statistics,
            "overdue": self.show_overdue_books,
            "providers": self.show_all_providers,
            "search": self.search_books,
            "employee": self.show_employee_info,
            "borrow": self.borrow_book,
            "return": self.return_book,
            "history": self.show_borrowing_history,
            "query": self.natural_language_query,
            "clear": self.clear_screen,
            "exit": self.exit_chatbot,
        }
    
    def show_welcome_message(self):
        """Show welcome message"""
        print_header("BOOK LIBRARY MANAGEMENT AGENTIC AI")
        print("""
╔════════════════════════════════════════════════════════════════════╗
║                 Welcome to Library AI Chatbot                      ║
║                                                                    ║
║  This AI Agent helps you manage the company library efficiently.  ║
║  You can query books, manage borrowing, and view statistics.      ║
║                                                                    ║
║  Type 'help' to see available commands                            ║
║  Type 'exit' to quit                                              ║
╚════════════════════════════════════════════════════════════════════╝
        """)
    
    def show_help(self, *args):
        """Show help message"""
        print_header("Available Commands", level=2)
        help_text = [
            ["help", "Show this help message"],
            ["tools", "List all available AI tools"],
            ["books", "Show all books in library"],
            ["available", "Show only available books"],
            ["employees", "Show all employees"],
            ["stats", "Show library statistics"],
            ["overdue", "Show overdue books"],
            ["providers", "Show all book providers"],
            ["search <keyword>", "Search books by title/author"],
            ["employee <EMP_ID>", "Show employee details and books"],
            ["borrow <EMP_ID> <BOOK_ID>", "Borrow a book"],
            ["return <EMP_ID> <BOOK_ID>", "Return a book"],
            ["history <EMP_ID>", "Show borrowing history"],
            ["query <natural language>", "Ask AI agent in natural language"],
            ["clear", "Clear screen"],
            ["exit", "Exit chatbot"],
        ]
        print_table(help_text, ["Command", "Description"])
    
    def list_tools(self, *args):
        """List all available tools"""
        tools = self.agent.get_available_tools()
        print_header("Available AI Tools", level=2)
        for i, tool in enumerate(tools, 1):
            print(f"  {i:2}. {tool}")
    
    def show_all_books(self, *args):
        """Show all books in library"""
        print_header("All Books in Library", level=2)
        result = json.loads(self.agent._get_all_books())
        
        if result['status'] == 'success' and result['data']:
            books_data = []
            for book in result['data']:
                books_data.append([
                    book['book_id'],
                    book['title'][:30],
                    book['author'][:25],
                    book['genre'],
                    book['available_copies'],
                    book['total_copies']
                ])
            print_table(books_data, 
                       ["Book ID", "Title", "Author", "Genre", "Available", "Total"])
        else:
            print_warning("No books found")
    
    def show_available_books(self, *args):
        """Show only available books"""
        print_header("Available Books", level=2)
        result = json.loads(self.agent._get_available_books())
        
        if result['status'] == 'success' and result['data']:
            books_data = []
            for book in result['data']:
                books_data.append([
                    book['book_id'],
                    book['title'][:30],
                    book['author'][:25],
                    book['genre'],
                    book['available_copies']
                ])
            print_table(books_data, 
                       ["Book ID", "Title", "Author", "Genre", "Available"])
            print_info(f"Total available: {result['count']} books")
        else:
            print_warning("No available books")
    
    def show_all_employees(self, *args):
        """Show all employees"""
        print_header("All Employees", level=2)
        result = json.loads(self.agent._get_all_employees())
        
        if result['status'] == 'success' and result['data']:
            emp_data = []
            for emp in result['data']:
                emp_data.append([
                    emp['employee_id'],
                    emp['name'][:25],
                    emp['department'],
                    emp['email'][:30]
                ])
            print_table(emp_data, 
                       ["Employee ID", "Name", "Department", "Email"])
            print_info(f"Total employees: {result['count']}")
        else:
            print_warning("No employees found")
    
    def show_all_providers(self, *args):
        """Show all book providers"""
        print_header("All Book Providers", level=2)
        result = json.loads(self.agent._get_all_providers())
        
        if result['status'] == 'success' and result['data']:
            prov_data = []
            for prov in result['data']:
                prov_data.append([
                    prov['provider_id'],
                    prov['provider_name'][:30],
                    prov['provider_type'],
                    prov['city']
                ])
            print_table(prov_data, 
                       ["Provider ID", "Name", "Type", "City"])
            print_info(f"Total providers: {result['count']}")
        else:
            print_warning("No providers found")
    
    def show_statistics(self, *args):
        """Show library statistics"""
        print_header("Library Statistics", level=2)
        result = json.loads(self.agent._get_library_stats())
        
        if result['status'] == 'success':
            stats = result['data']
            stats_display = [
                ["Total Books", stats['total_books']],
                ["Available Books", stats['available_books']],
                ["Borrowed Books", stats['borrowed_books']],
                ["Total Employees", stats['total_employees']],
                ["Total Providers", stats['total_providers']],
            ]
            print_table(stats_display, ["Metric", "Count"])
    
    def show_overdue_books(self, *args):
        """Show overdue books"""
        print_header("Overdue Books", level=2)
        result = json.loads(self.agent._get_overdue_books())
        
        if result['status'] == 'success' and result['data']:
            overdue_data = []
            for item in result['data']:
                overdue_data.append([
                    item['title'][:30],
                    item['name'][:20],
                    item['due_date'],
                    f"{int(item['days_overdue'])} days"
                ])
            print_table(overdue_data, 
                       ["Book Title", "Employee", "Due Date", "Days Overdue"])
            print_warning(f"⚠️  {result['count']} overdue book(s)")
        else:
            print_success("No overdue books!")
    
    def search_books(self, *args):
        """Search for books"""
        keyword = " ".join(args) if args else input("Enter search keyword: ").strip()
        if not keyword:
            print_warning("Please provide a search keyword")
            return
        
        print_header(f"Search Results for '{keyword}'", level=2)
        result = json.loads(self.agent._search_books(keyword=keyword))
        
        if result['status'] == 'success' and result['data']:
            books_data = []
            for book in result['data']:
                books_data.append([
                    book['book_id'],
                    book['title'][:30],
                    book['author'][:25],
                    book['available_copies'],
                    book['total_copies']
                ])
            print_table(books_data, 
                       ["Book ID", "Title", "Author", "Available", "Total"])
            print_info(f"Found {result['count']} book(s)")
        else:
            print_warning(f"No books found for '{keyword}'")
    
    def show_employee_info(self, *args):
        """Show employee information"""
        emp_id = " ".join(args) if args else input("Enter Employee ID (e.g., EMP001): ").strip().upper()
        
        if not emp_id:
            print_warning("Please provide an employee ID")
            return
        
        result = json.loads(self.agent._get_employee_details(employee_id=emp_id))
        
        if result['status'] == 'success':
            emp = result['data']
            print_header(f"Employee: {emp['name']}", level=2)
            emp_info = [
                ["Employee ID", emp['employee_id']],
                ["Name", emp['name']],
                ["Department", emp['department']],
                ["Email", emp['email']],
                ["Phone", emp['phone']],
                ["Joining Date", emp['joining_date']],
            ]
            print_table(emp_info, ["Field", "Value"])
            
            # Show books
            books_result = json.loads(self.agent._get_employee_books(employee_id=emp_id))
            if books_result['status'] == 'success' and books_result['data']:
                print_header(f"Books Held by {emp['name']}", level=2)
                books_data = []
                for book in books_result['data']:
                    books_data.append([
                        book['title'][:30],
                        book['author'][:25],
                        book['borrow_date'],
                        book['due_date'],
                        book['status']
                    ])
                print_table(books_data, 
                           ["Title", "Author", "Borrow Date", "Due Date", "Status"])
            else:
                print_info(f"{emp['name']} is not currently holding any books")
        else:
            print_error(f"Employee not found: {emp_id}")
    
    def borrow_book(self, *args):
        """Borrow a book"""
        if len(args) >= 2:
            emp_id = args[0].upper()
            book_id = args[1].upper()
        else:
            emp_id = input("Enter Employee ID (e.g., EMP001): ").strip().upper()
            book_id = input("Enter Book ID (e.g., B001): ").strip().upper()
        
        if not emp_id or not book_id:
            print_warning("Please provide both Employee ID and Book ID")
            return
        
        print_header("Processing Book Borrowing", level=2)
        result = json.loads(self.agent._borrow_book(employee_id=emp_id, book_id=book_id))
        
        if result['status'] == 'success':
            print_success(result['message'])
        else:
            print_error(result['message'])
    
    def return_book(self, *args):
        """Return a book"""
        if len(args) >= 2:
            emp_id = args[0].upper()
            book_id = args[1].upper()
        else:
            emp_id = input("Enter Employee ID (e.g., EMP001): ").strip().upper()
            book_id = input("Enter Book ID (e.g., B001): ").strip().upper()
        
        if not emp_id or not book_id:
            print_warning("Please provide both Employee ID and Book ID")
            return
        
        print_header("Processing Book Return", level=2)
        result = json.loads(self.agent._return_book(employee_id=emp_id, book_id=book_id))
        
        if result['status'] == 'success':
            print_success(result['message'])
        else:
            print_error(result['message'])
    
    def show_borrowing_history(self, *args):
        """Show borrowing history"""
        emp_id = " ".join(args) if args else input("Enter Employee ID (e.g., EMP001): ").strip().upper()
        
        if not emp_id:
            print_warning("Please provide an employee ID")
            return
        
        print_header(f"Borrowing History - {emp_id}", level=2)
        result = json.loads(self.agent._get_borrowing_history(employee_id=emp_id))
        
        if result['status'] == 'success' and result['data']:
            history_data = []
            for item in result['data']:
                history_data.append([
                    item['title'][:30],
                    item['author'][:20],
                    item['borrow_date'],
                    item['due_date'],
                    item['return_date'] or "Not Returned",
                    item['status']
                ])
            print_table(history_data, 
                       ["Title", "Author", "Borrow Date", "Due Date", "Return Date", "Status"])
        else:
            print_info("No borrowing history found")
    
    def natural_language_query(self, *args):
        """Process natural language query"""
        query = " ".join(args) if args else input("Enter your query: ").strip()
        
        if not query:
            print_warning("Please provide a query")
            return
        
        print_header("AI Agent Processing Query", level=2)
        result = self.agent.process_request(query)
        result_obj = json.loads(result)
        
        if result_obj['status'] == 'success' and 'data' in result_obj:
            data = result_obj['data']
            if isinstance(data, list) and data:
                print_info(f"Found {len(data)} result(s)")
                if all(isinstance(item, dict) for item in data):
                    print(json.dumps(data, indent=2))
                else:
                    print_table([[item] for item in data], ["Result"])
            else:
                print_table([[k, v] for k, v in data.items()], ["Field", "Value"])
        else:
            print_info(result_obj.get('message', 'Query processed'))
    
    def clear_screen(self, *args):
        """Clear screen"""
        import os
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def exit_chatbot(self, *args):
        """Exit chatbot"""
        print("\n")
        print_header("Thank You!", level=2)
        print("👋 Thank you for using Library AI Chatbot!")
        print("Have a great day!\n")
        exit(0)
    
    def run(self):
        """Run the chatbot"""
        self.show_welcome_message()
        
        while True:
            try:
                user_input = input("\n📚 Library> ").strip()
                
                if not user_input:
                    continue
                
                # Parse command and arguments
                parts = user_input.split(maxsplit=1)
                command = parts[0].lower()
                args = parts[1].split() if len(parts) > 1 else []
                
                if command in self.commands:
                    self.commands[command](*args)
                else:
                    # Try as natural language query
                    print_warning(f"Unknown command: {command}")
                    print_info("Trying as natural language query...")
                    self.natural_language_query(user_input)
            
            except KeyboardInterrupt:
                self.exit_chatbot()
            except Exception as e:
                print_error(f"Error: {str(e)}")