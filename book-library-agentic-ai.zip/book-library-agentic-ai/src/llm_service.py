"""
Open Source LLM Service Integration
Supports: Ollama (Local), LLaMA2, Mistral, etc.
"""

import requests
import json
from typing import Dict, Optional
from src.utils import print_info, print_error, print_warning

class LLMService:
    """Service for interacting with open-source LLMs"""
    
    def __init__(self, model: str = "mistral", base_url: str = "http://localhost:11434"):
        """
        Initialize LLM Service
        
        Args:
            model: Model name (mistral, llama2, neural-chat, etc.)
            base_url: Ollama server URL
        """
        self.model = model
        self.base_url = base_url
        self.api_endpoint = f"{base_url}/api/generate"
        self.chat_endpoint = f"{base_url}/api/chat"
    
    def check_connection(self) -> bool:
        """Check if Ollama server is running"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except requests.exceptions.ConnectionError:
            return False
        except Exception as e:
            print_error(f"Connection check error: {str(e)}")
            return False
    
    def get_available_models(self) -> list:
        """Get list of available models"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = [model['name'] for model in data.get('models', [])]
                return models
            return []
        except Exception as e:
            print_error(f"Error getting models: {str(e)}")
            return []
    
    def generate_response(self, prompt: str, context: str = "") -> str:
        """
        Generate response from LLM
        
        Args:
            prompt: User query
            context: Additional context (e.g., book data)
        
        Returns:
            Generated response
        """
        try:
            # Build full prompt with context
            full_prompt = f"""You are a helpful library management assistant. 
Your role is to help employees manage the company library efficiently.

{context}

User Query: {prompt}

Please provide a helpful and concise response."""
            
            payload = {
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "temperature": 0.7
            }
            
            response = requests.post(
                self.api_endpoint,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('response', 'No response generated')
            else:
                return f"Error: {response.status_code}"
        
        except requests.exceptions.Timeout:
            return "Request timeout. Please try again."
        except requests.exceptions.ConnectionError:
            return "Cannot connect to LLM server. Is Ollama running?"
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def generate_chat_response(self, messages: list, system_prompt: str = "") -> str:
        """
        Generate chat response using chat endpoint
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            system_prompt: System instruction
        
        Returns:
            Generated response
        """
        try:
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": False
            }
            
            response = requests.post(
                self.chat_endpoint,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('message', {}).get('content', 'No response')
            else:
                return f"Error: {response.status_code}"
        
        except requests.exceptions.ConnectionError:
            return "Cannot connect to LLM server. Is Ollama running?"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def format_library_context(self, data: Dict) -> str:
        """Format library data as context for LLM"""
        context = "\n=== LIBRARY DATA ===\n"
        
        if 'books' in data and data['books']:
            context += "\nAvailable Books:\n"
            for book in data['books'][:5]:  # Limit to 5 to keep prompt manageable
                context += f"- {book.get('title', 'N/A')} by {book.get('author', 'N/A')} ({book.get('available_copies', 0)} copies available)\n"
        
        if 'employees' in data and data['employees']:
            context += "\nEmployees:\n"
            for emp in data['employees'][:3]:
                context += f"- {emp.get('name', 'N/A')} ({emp.get('employee_id', 'N/A')}) - {emp.get('department', 'N/A')}\n"
        
        if 'borrowed_books' in data and data['borrowed_books']:
            context += "\nCurrently Borrowed Books:\n"
            for borrow in data['borrowed_books'][:5]:
                context += f"- {borrow.get('title', 'N/A')} borrowed by {borrow.get('employee_name', 'N/A')} (Due: {borrow.get('due_date', 'N/A')})\n"
        
        return context


class LocalLLMChatbot:
    """Chatbot using local open-source LLM"""
    
    def __init__(self, model: str = "mistral", base_url: str = "http://localhost:11434"):
        self.llm = LLMService(model, base_url)
        self.conversation_history = []
        self.model = model
        self.base_url = base_url
    
    def is_available(self) -> bool:
        """Check if LLM service is available"""
        return self.llm.check_connection()
    
    def add_to_history(self, role: str, content: str):
        """Add message to conversation history"""
        self.conversation_history.append({
            "role": role,
            "content": content
        })
    
    def get_response(self, user_message: str, context: str = "") -> str:
        """Get response for user message"""
        # Add user message to history
        self.add_to_history("user", user_message)
        
        # Generate response
        if context:
            response = self.llm.generate_response(user_message, context)
        else:
            response = self.llm.generate_chat_response(self.conversation_history)
        
        # Add assistant response to history
        self.add_to_history("assistant", response)
        
        return response
    
    def clear_history(self):
        """Clear conversation history"""
        self.conversation_history = []