#!/usr/bin/env python3
"""
LangChain Library Agent CLI
Command-line interface with intelligent agent
"""

import os
import sys
from src.langchain_library_agent import LangChainLibraryAgent
from src.utils import (
    print_header, print_success, print_error, print_info,
    print_warning, Colors
)

def main():
    """Main function"""
    try:
        print_header("LANGCHAIN LIBRARY MANAGEMENT AGENT")
        
        print_info("\n🤖 Choose LLM Provider:\n")
        print("1. Groq (RECOMMENDED - Fastest)")
        print("   🔗 Sign up: https://console.groq.com\n")
        print("2. Google Generative AI")
        print("   🔗 Sign up: https://makersuite.google.com\n")
        
        choice = input("Choose (1 or 2, default 1): ").strip() or "1"
        
        if choice == "1":
            provider = "groq"
            signup_url = "https://console.groq.com"
        elif choice == "2":
            provider = "google"
            signup_url = "https://makersuite.google.com"
        else:
            provider = "groq"
            signup_url = "https://console.groq.com"
        
        print(f"\n✓ Using {provider.upper()}")
        print(f"📍 Sign up: {signup_url}\n")
        
        api_key = input("Enter your API key: ").strip()
        
        if not api_key:
            print_error("API key is required!")
            sys.exit(1)
        
        print_success("Initializing agent...")
        
        # Initialize agent
        agent = LangChainLibraryAgent(
            provider=provider,
            api_key=api_key
        )
        
        print_success("✓ Agent ready!\n")
        print_header("CHAT INTERFACE", level=2)
        print("Type 'quit' to exit\n")
        
        # Chat loop
        while True:
            try:
                user_input = input(f"\n{Colors.HEADER}📚 You>{Colors.RESET} ").strip()
                
                if user_input.lower() in ['quit', 'exit']:
                    print_info("\n👋 Goodbye!")
                    break
                
                if not user_input:
                    continue
                
                print(f"\n{Colors.INFO}🤖 Agent thinking...{Colors.RESET}")
                response = agent.chat(user_input)
                print(f"\n{Colors.SUCCESS}{response}{Colors.RESET}")
            
            except KeyboardInterrupt:
                print_info("\n👋 Goodbye!")
                break
            except Exception as e:
                print_error(f"Error: {str(e)}")
    
    except KeyboardInterrupt:
        print_info("\n👋 Exiting...")
        sys.exit(0)
    except Exception as e:
        print_error(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()