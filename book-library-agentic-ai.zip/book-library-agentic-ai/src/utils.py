from datetime import datetime, timedelta
from colorama import Fore, Style, init
from tabulate import tabulate
import json
import os

init(autoreset=True)

class Colors:
    """ANSI color codes"""
    HEADER = Fore.CYAN
    SUCCESS = Fore.GREEN
    WARNING = Fore.YELLOW
    ERROR = Fore.RED
    INFO = Fore.BLUE
    RESET = Style.RESET_ALL

def print_header(text: str, level: int = 1):
    """Print formatted header"""
    if level == 1:
        print(f"\n{Colors.HEADER}{'='*70}")
        print(f"  {text.upper()}")
        print(f"{'='*70}{Colors.RESET}\n")
    else:
        print(f"\n{Colors.HEADER}{'-'*70}")
        print(f"  {text}")
        print(f"{'-'*70}{Colors.RESET}\n")

def print_success(text: str):
    """Print success message"""
    print(f"{Colors.SUCCESS}✓ {text}{Colors.RESET}")

def print_error(text: str):
    """Print error message"""
    print(f"{Colors.ERROR}✗ {text}{Colors.RESET}")

def print_warning(text: str):
    """Print warning message"""
    print(f"{Colors.WARNING}⚠ {text}{Colors.RESET}")

def print_info(text: str):
    """Print info message"""
    print(f"{Colors.INFO}ℹ {text}{Colors.RESET}")

def print_table(data: list, headers: list, title: str = None):
    """Print formatted table"""
    if title:
        print(f"\n{Colors.HEADER}{title}{Colors.RESET}")
    print(tabulate(data, headers=headers, tablefmt="grid"))

def parse_date(date_str: str) -> datetime:
    """Parse date string to datetime object"""
    if isinstance(date_str, datetime):
        return date_str
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except:
        return datetime.now()

def format_date(date_obj) -> str:
    """Format datetime object to string"""
    if isinstance(date_obj, str):
        return date_obj
    return date_obj.strftime("%Y-%m-%d") if date_obj else "N/A"

def get_days_until_due(due_date_str: str) -> int:
    """Calculate days until due date"""
    due_date = parse_date(due_date_str)
    return (due_date - datetime.now()).days

def is_overdue(due_date_str: str) -> bool:
    """Check if due date has passed"""
    return get_days_until_due(due_date_str) < 0

def save_json(data: dict, filename: str):
    """Save data to JSON file"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    print_success(f"Data saved to {filename}")

def load_json(filename: str) -> dict:
    """Load data from JSON file"""
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print_error(f"File not found: {filename}")
        return {}

def create_logs_directory():
    """Create logs directory if it doesn't exist"""
    logs_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
    os.makedirs(logs_dir, exist_ok=True)