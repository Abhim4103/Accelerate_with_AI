"""
REST API Server for Book Library Management
Provides endpoints for all library operations
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import json
from src.database_manager import DatabaseManager
from src.utils import format_date, get_days_until_due, is_overdue

class LibraryAPI:
    """REST API Server for Library Management"""
    
    def __init__(self, port: int = 5000):
        self.app = Flask(__name__)
        CORS(self.app)
        self.db = DatabaseManager()
        self.port = port
        self._register_routes()
    
    def _register_routes(self):
        """Register all API routes"""
        
        # Health Check
        @self.app.route('/api/health', methods=['GET'])
        def health_check():
            """Health check endpoint"""
            return jsonify({
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "version": "1.0.0"
            }), 200
        
        # ==================== BOOKS ENDPOINTS ====================
        
        @self.app.route('/api/books', methods=['GET'])
        def get_books():
            """Get all books"""
            try:
                books = self.db.get_all_books()
                return jsonify({
                    "status": "success",
                    "data": books,
                    "count": len(books),
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/books/available', methods=['GET'])
        def get_available_books():
            """Get only available books"""
            try:
                books = self.db.get_all_books()
                available = [b for b in books if b['available_copies'] > 0]
                return jsonify({
                    "status": "success",
                    "data": available,
                    "count": len(available),
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/books/<book_id>', methods=['GET'])
        def get_book(book_id):
            """Get book details by ID"""
            try:
                book = self.db.get_book_by_id(book_id)
                if not book:
                    return jsonify({
                        "status": "error",
                        "message": f"Book {book_id} not found"
                    }), 404
                return jsonify({
                    "status": "success",
                    "data": book,
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/books/search', methods=['GET'])
        def search_books():
            """Search books by keyword"""
            try:
                keyword = request.args.get('q', '')
                if not keyword:
                    return jsonify({
                        "status": "error",
                        "message": "Search keyword required"
                    }), 400
                
                books = self.db.search_books(keyword)
                return jsonify({
                    "status": "success",
                    "data": books,
                    "count": len(books),
                    "keyword": keyword,
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== EMPLOYEES ENDPOINTS ====================
        
        @self.app.route('/api/employees', methods=['GET'])
        def get_employees():
            """Get all employees"""
            try:
                employees = self.db.get_all_employees()
                return jsonify({
                    "status": "success",
                    "data": employees,
                    "count": len(employees),
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/employees/<employee_id>', methods=['GET'])
        def get_employee(employee_id):
            """Get employee details"""
            try:
                employee = self.db.get_employee_by_id(employee_id)
                if not employee:
                    return jsonify({
                        "status": "error",
                        "message": f"Employee {employee_id} not found"
                    }), 404
                return jsonify({
                    "status": "success",
                    "data": employee,
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== BORROWED BOOKS ENDPOINTS ====================
        
        @self.app.route('/api/borrowed', methods=['GET'])
        def get_all_borrowed_books():
            """Get all currently borrowed books with detailed information"""
            try:
                import sqlite3
                from config.settings import DATABASE_PATH
                
                conn = sqlite3.connect(DATABASE_PATH)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 
                        b.book_id,
                        b.title,
                        b.author,
                        b.isbn,
                        b.genre,
                        e.employee_id,
                        e.name as employee_name,
                        e.email,
                        e.department,
                        br.borrow_date,
                        br.due_date,
                        br.status,
                        CASE 
                            WHEN br.due_date < DATE('now') THEN 'overdue'
                            WHEN (julianday(br.due_date) - julianday('now')) <= 3 THEN 'due_soon'
                            ELSE 'on_time'
                        END as due_status,
                        CAST((julianday('now') - julianday(br.due_date)) as INTEGER) as days_overdue,
                        CAST((julianday(br.due_date) - julianday('now')) as INTEGER) as days_remaining
                    FROM borrowers br
                    JOIN books b ON br.book_id = b.book_id
                    JOIN employees e ON br.employee_id = e.employee_id
                    WHERE br.status = 'borrowed'
                    ORDER BY br.due_date ASC
                ''')
                
                borrowed = []
                for row in cursor.fetchall():
                    borrowed.append({
                        "book_id": row['book_id'],
                        "title": row['title'],
                        "author": row['author'],
                        "isbn": row['isbn'],
                        "genre": row['genre'],
                        "employee_id": row['employee_id'],
                        "employee_name": row['employee_name'],
                        "email": row['email'],
                        "department": row['department'],
                        "borrow_date": row['borrow_date'],
                        "due_date": row['due_date'],
                        "status": row['status'],
                        "due_status": row['due_status'],
                        "days_overdue": row['days_overdue'],
                        "days_remaining": row['days_remaining']
                    })
                
                conn.close()
                
                return jsonify({
                    "status": "success",
                    "data": borrowed,
                    "count": len(borrowed),
                    "timestamp": datetime.now().isoformat()
                }), 200
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/employees/<employee_id>/borrowed', methods=['GET'])
        def get_employee_borrowed_books(employee_id):
            """Get all books borrowed by a specific employee with detailed info"""
            try:
                import sqlite3
                from config.settings import DATABASE_PATH
                
                # Verify employee exists
                employee = self.db.get_employee_by_id(employee_id)
                if not employee:
                    return jsonify({
                        "status": "error",
                        "message": f"Employee {employee_id} not found"
                    }), 404
                
                conn = sqlite3.connect(DATABASE_PATH)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 
                        b.book_id,
                        b.title,
                        b.author,
                        b.isbn,
                        b.genre,
                        br.borrow_date,
                        br.due_date,
                        br.return_date,
                        br.status,
                        CASE 
                            WHEN br.due_date < DATE('now') AND br.status = 'borrowed' THEN 'overdue'
                            WHEN (julianday(br.due_date) - julianday('now')) <= 3 AND br.status = 'borrowed' THEN 'due_soon'
                            WHEN br.status = 'borrowed' THEN 'on_time'
                            ELSE 'returned'
                        END as due_status,
                        CAST((julianday('now') - julianday(br.due_date)) as INTEGER) as days_overdue,
                        CAST((julianday(br.due_date) - julianday('now')) as INTEGER) as days_remaining
                    FROM borrowers br
                    JOIN books b ON br.book_id = b.book_id
                    WHERE br.employee_id = (SELECT id FROM employees WHERE employee_id = ?)
                    ORDER BY br.borrow_date DESC
                ''', (employee_id,))
                
                borrowed = []
                for row in cursor.fetchall():
                    borrowed.append({
                        "book_id": row['book_id'],
                        "title": row['title'],
                        "author": row['author'],
                        "isbn": row['isbn'],
                        "genre": row['genre'],
                        "borrow_date": row['borrow_date'],
                        "due_date": row['due_date'],
                        "return_date": row['return_date'],
                        "status": row['status'],
                        "due_status": row['due_status'],
                        "days_overdue": row['days_overdue'],
                        "days_remaining": row['days_remaining']
                    })
                
                conn.close()
                
                return jsonify({
                    "status": "success",
                    "data": {
                        "employee": {
                            "employee_id": employee['employee_id'],
                            "name": employee['name'],
                            "department": employee['department'],
                            "email": employee['email']
                        },
                        "borrowed_books": borrowed,
                        "active_borrows": len([b for b in borrowed if b['status'] == 'borrowed']),
                        "overdue_books": len([b for b in borrowed if b['due_status'] == 'overdue'])
                    },
                    "count": len(borrowed),
                    "timestamp": datetime.now().isoformat()
                }), 200
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/borrowed/overdue', methods=['GET'])
        def get_overdue_books():
            """Get all overdue books"""
            try:
                overdue = self.db.get_overdue_books()
                
                overdue_formatted = []
                for item in overdue:
                    overdue_formatted.append({
                        "book_title": item['title'],
                        "author": item.get('author', 'N/A'),
                        "employee_name": item['name'],
                        "employee_id": item.get('employee_id', 'N/A'),
                        "email": item['email'],
                        "due_date": item['due_date'],
                        "days_overdue": int(item['days_overdue']),
                        "urgency": "critical" if int(item['days_overdue']) > 7 else "high" if int(item['days_overdue']) > 3 else "medium"
                    })
                
                return jsonify({
                    "status": "success",
                    "data": overdue_formatted,
                    "count": len(overdue_formatted),
                    "timestamp": datetime.now().isoformat()
                }), 200
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/borrowed/due-soon', methods=['GET'])
        def get_due_soon_books():
            """Get books due within 3 days"""
            try:
                import sqlite3
                from config.settings import DATABASE_PATH
                
                conn = sqlite3.connect(DATABASE_PATH)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 
                        b.book_id,
                        b.title,
                        b.author,
                        e.employee_id,
                        e.name,
                        e.email,
                        br.due_date,
                        CAST((julianday(br.due_date) - julianday('now')) as INTEGER) as days_remaining
                    FROM borrowers br
                    JOIN books b ON br.book_id = b.book_id
                    JOIN employees e ON br.employee_id = e.employee_id
                    WHERE br.status = 'borrowed'
                        AND br.due_date >= DATE('now')
                        AND br.due_date <= DATE('now', '+3 days')
                    ORDER BY br.due_date ASC
                ''')
                
                due_soon = []
                for row in cursor.fetchall():
                    due_soon.append({
                        "book_id": row['book_id'],
                        "title": row['title'],
                        "author": row['author'],
                        "employee_id": row['employee_id'],
                        "employee_name": row['name'],
                        "email": row['email'],
                        "due_date": row['due_date'],
                        "days_remaining": row['days_remaining']
                    })
                
                conn.close()
                
                return jsonify({
                    "status": "success",
                    "data": due_soon,
                    "count": len(due_soon),
                    "timestamp": datetime.now().isoformat()
                }), 200
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== BORROWING OPERATIONS ====================
        
        @self.app.route('/api/borrow', methods=['POST'])
        def borrow_book():
            """Borrow a book"""
            try:
                data = request.get_json()
                
                if not data or 'employee_id' not in data or 'book_id' not in data:
                    return jsonify({
                        "status": "error",
                        "message": "employee_id and book_id are required"
                    }), 400
                
                employee_id = data['employee_id']
                book_id = data['book_id']
                due_days = data.get('due_days', 14)
                
                result = self.db.borrow_book(employee_id, book_id, due_days)
                
                if result['status'] == 'success':
                    return jsonify(result), 200
                else:
                    return jsonify(result), 400
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/return', methods=['POST'])
        def return_book():
            """Return a book"""
            try:
                data = request.get_json()
                
                if not data or 'employee_id' not in data or 'book_id' not in data:
                    return jsonify({
                        "status": "error",
                        "message": "employee_id and book_id are required"
                    }), 400
                
                employee_id = data['employee_id']
                book_id = data['book_id']
                
                result = self.db.return_book(employee_id, book_id)
                
                if result['status'] == 'success':
                    return jsonify(result), 200
                else:
                    return jsonify(result), 400
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== PROVIDERS ENDPOINTS ====================
        
        @self.app.route('/api/providers', methods=['GET'])
        def get_providers():
            """Get all book providers"""
            try:
                providers = self.db.get_all_providers()
                return jsonify({
                    "status": "success",
                    "data": providers,
                    "count": len(providers),
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/providers/<provider_id>/books', methods=['GET'])
        def get_provider_books(provider_id):
            """Get all books from a provider"""
            try:
                books = self.db.get_provider_books(provider_id)
                return jsonify({
                    "status": "success",
                    "data": books,
                    "count": len(books),
                    "provider_id": provider_id,
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== STATISTICS ENDPOINTS ====================
        
        @self.app.route('/api/stats', methods=['GET'])
        def get_stats():
            """Get library statistics"""
            try:
                stats = self.db.get_library_stats()
                return jsonify({
                    "status": "success",
                    "data": stats,
                    "timestamp": datetime.now().isoformat()
                }), 200
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        @self.app.route('/api/stats/dashboard', methods=['GET'])
        def get_dashboard_stats():
            """Get comprehensive dashboard statistics"""
            try:
                import sqlite3
                from config.settings import DATABASE_PATH
                
                conn = sqlite3.connect(DATABASE_PATH)
                cursor = conn.cursor()
                
                # Get basic stats
                cursor.execute('SELECT COUNT(*) FROM books')
                total_books = cursor.fetchone()[0]
                
                cursor.execute('SELECT SUM(available_copies) FROM books')
                available_books = cursor.fetchone()[0] or 0
                
                cursor.execute('SELECT COUNT(*) FROM borrowers WHERE status = "borrowed"')
                borrowed_books = cursor.fetchone()[0]
                
                cursor.execute('SELECT COUNT(*) FROM employees')
                total_employees = cursor.fetchone()[0]
                
                cursor.execute('SELECT COUNT(*) FROM providers')
                total_providers = cursor.fetchone()[0]
                
                # Get overdue count
                cursor.execute('''
                    SELECT COUNT(*) FROM borrowers 
                    WHERE status = 'borrowed' AND due_date < DATE('now')
                ''')
                overdue_count = cursor.fetchone()[0]
                
                # Get due soon count
                cursor.execute('''
                    SELECT COUNT(*) FROM borrowers 
                    WHERE status = 'borrowed' 
                        AND due_date >= DATE('now')
                        AND due_date <= DATE('now', '+3 days')
                ''')
                due_soon_count = cursor.fetchone()[0]
                
                # Get most borrowed books
                cursor.execute('''
                    SELECT b.title, b.book_id, COUNT(*) as borrow_count
                    FROM borrowers br
                    JOIN books b ON br.book_id = b.book_id
                    GROUP BY br.book_id
                    ORDER BY borrow_count DESC
                    LIMIT 5
                ''')
                most_borrowed = [{"title": row[0], "book_id": row[1], "borrow_count": row[2]} for row in cursor.fetchall()]
                
                # Get top borrowers
                cursor.execute('''
                    SELECT e.name, e.employee_id, COUNT(*) as borrow_count
                    FROM borrowers br
                    JOIN employees e ON br.employee_id = e.employee_id
                    GROUP BY br.employee_id
                    ORDER BY borrow_count DESC
                    LIMIT 5
                ''')
                top_borrowers = [{"name": row[0], "employee_id": row[1], "borrow_count": row[2]} for row in cursor.fetchall()]
                
                conn.close()
                
                return jsonify({
                    "status": "success",
                    "data": {
                        "summary": {
                            "total_books": total_books,
                            "available_books": available_books,
                            "borrowed_books": borrowed_books,
                            "total_employees": total_employees,
                            "total_providers": total_providers
                        },
                        "alerts": {
                            "overdue_books": overdue_count,
                            "due_soon": due_soon_count
                        },
                        "top_books": most_borrowed,
                        "top_borrowers": top_borrowers
                    },
                    "timestamp": datetime.now().isoformat()
                }), 200
            
            except Exception as e:
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500
        
        # ==================== ERROR HANDLERS ====================
        
        @self.app.errorhandler(404)
        def not_found(error):
            """Handle 404 errors"""
            return jsonify({
                "status": "error",
                "message": "Endpoint not found"
            }), 404
        
        @self.app.errorhandler(500)
        def internal_error(error):
            """Handle 500 errors"""
            return jsonify({
                "status": "error",
                "message": "Internal server error"
            }), 500
    
    def run(self, debug: bool = True):
        """Run the API server"""
        print(f"\n{'='*70}")
        print(f"  📚 BOOK LIBRARY API SERVER")
        print(f"{'='*70}\n")
        print(f"🚀 Server starting on http://localhost:{self.port}")
        print(f"\n📋 Available Endpoints:")
        print(f"   GET  http://localhost:{self.port}/api/health")
        print(f"   GET  http://localhost:{self.port}/api/books")
        print(f"   GET  http://localhost:{self.port}/api/books/available")
        print(f"   GET  http://localhost:{self.port}/api/borrowed")
        print(f"   GET  http://localhost:{self.port}/api/employees/<ID>/borrowed")
        print(f"   GET  http://localhost:{self.port}/api/borrowed/overdue")
        print(f"   GET  http://localhost:{self.port}/api/borrowed/due-soon")
        print(f"   GET  http://localhost:{self.port}/api/stats/dashboard")
        print(f"\n💡 Open http://localhost:{self.port}/api/health in browser to test\n")
        self.app.run(host='0.0.0.0', port=self.port, debug=debug)


if __name__ == '__main__':
    api = LibraryAPI(port=5000)
    api.run()
