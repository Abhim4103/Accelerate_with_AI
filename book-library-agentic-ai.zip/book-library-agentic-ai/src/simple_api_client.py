"""
Simple API Client without LangChain
Direct connection to Library REST API
"""

import requests
from typing import Dict, List, Optional
from src.utils import print_error, print_info

class SimpleLibraryClient:
    """Simple client for Library API"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
    
    def _request(self, endpoint: str, method: str = "GET", data: Dict = None) -> Optional[Dict]:
        """Make API request"""
        try:
            url = f"{self.base_url}{endpoint}"
            
            if method == "GET":
                response = requests.get(url, headers=self.headers, timeout=5)
            else:
                response = requests.post(url, json=data, headers=self.headers, timeout=5)
            
            if response.status_code in [200, 201]:
                return response.json()
            return None
        
        except requests.exceptions.ConnectionError:
            print_error("Cannot connect to API. Is api_main.py running?")
            return None
        except Exception as e:
            print_error(f"API Error: {str(e)}")
            return None
    
    def get_all_books(self) -> List[Dict]:
        """Get all books"""
        result = self._request("/api/books")
        return result.get('data', []) if result else []
    
    def get_available_books(self) -> List[Dict]:
        """Get available books"""
        result = self._request("/api/books/available")
        return result.get('data', []) if result else []
    
    def get_borrowed_books(self) -> List[Dict]:
        """Get all borrowed books"""
        result = self._request("/api/borrowed")
        return result.get('data', []) if result else []
    
    def get_employee_books(self, emp_id: str) -> Dict:
        """Get employee's borrowed books"""
        result = self._request(f"/api/employees/{emp_id}/borrowed")
        return result.get('data', {}) if result else {}
    
    def get_overdue_books(self) -> List[Dict]:
        """Get overdue books"""
        result = self._request("/api/borrowed/overdue")
        return result.get('data', []) if result else []
    
    def get_due_soon(self) -> List[Dict]:
        """Get books due soon"""
        result = self._request("/api/borrowed/due-soon")
        return result.get('data', []) if result else []
    
    def get_stats(self) -> Dict:
        """Get statistics"""
        result = self._request("/api/stats/dashboard")
        return result.get('data', {}) if result else {}
    
    def get_employees(self) -> List[Dict]:
        """Get all employees"""
        result = self._request("/api/employees")
        return result.get('data', []) if result else []
    
    def search_books(self, keyword: str) -> List[Dict]:
        """Search books"""
        result = self._request(f"/api/books/search?q={keyword}")
        return result.get('data', []) if result else []
    
    def borrow_book(self, emp_id: str, book_id: str) -> Dict:
        """Borrow book"""
        return self._request("/api/borrow", method="POST",
                           data={"employee_id": emp_id, "book_id": book_id}) or {}
    
    def return_book(self, emp_id: str, book_id: str) -> Dict:
        """Return book"""
        return self._request("/api/return", method="POST",
                           data={"employee_id": emp_id, "book_id": book_id}) or {}