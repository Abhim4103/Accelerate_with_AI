"""
Streamlit Dashboard for Library Management
Modern web interface with LLM chatbot
"""

import streamlit as st
import pandas as pd
import requests
from datetime import datetime
from src.langchain_library_agent import LangChainLibraryAgent
from src.utils import print_success, print_error

# Page config
st.set_page_config(
    page_title="📚 Library AI Assistant",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main {
        padding: 2rem;
    }
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
        font-size: 1.2rem;
    }
    .book-card {
        background: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .overdue {
        background: #ffcccc;
        color: #cc0000;
    }
    .due-soon {
        background: #ffffcc;
        color: #cc8800;
    }
    .on-time {
        background: #ccffcc;
        color: #008800;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

# Sidebar
with st.sidebar:
    st.title("⚙️ Configuration")
    
    provider = st.selectbox(
        "Choose LLM Provider",
        ["groq", "google"]
    )
    
    api_key = st.text_input(
        "API Key",
        type="password",
        help="Get free API key from Groq or Google"
    )
    
    if st.button("🚀 Initialize Agent"):
        if not api_key:
            st.error("Please enter API key")
        else:
            try:
                st.session_state.agent = LangChainLibraryAgent(
                    provider=provider,
                    api_key=api_key
                )
                st.success("✓ Agent initialized!")
            except Exception as e:
                st.error(f"Error: {str(e)}")
    
    st.divider()
    st.markdown("### 📖 Quick Links")
    st.markdown("""
- [Groq API](https://console.groq.com)
- [Google Generative AI](https://makersuite.google.com)
    """)

# Main content
st.title("📚 Library Management AI Assistant")

if st.session_state.agent is None:
    st.warning("⚠️ Please configure and initialize the agent in the sidebar")
else:
    # Create tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "💬 Chat", "📊 Dashboard", "📖 Borrowed Books", 
        "⏰ Overdue Books", "🔍 Search"
    ])
    
    # Tab 1: Chat
    with tab1:
        st.header("💬 Chat with AI Assistant")
        
        # Chat history
        for i, msg in enumerate(st.session_state.chat_history):
            if msg["role"] == "user":
                st.write(f"👤 **You**: {msg['content']}")
            else:
                st.write(f"🤖 **AI**: {msg['content']}")
        
        # Input
        user_input = st.text_input("Ask me anything about the library:")
        
        if user_input:
            try:
                response = st.session_state.agent.chat(user_input)
                st.session_state.chat_history.append({"role": "user", "content": user_input})
                st.session_state.chat_history.append({"role": "assistant", "content": response})
                st.rerun()
            except Exception as e:
                st.error(f"Error: {str(e)}")
    
    # Tab 2: Dashboard
    with tab2:
        st.header("📊 Library Dashboard")
        
        try:
            stats = st.session_state.agent.api_client.get_stats()
            summary = stats.get('summary', {})
            alerts = stats.get('alerts', {})
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("📚 Total Books", summary.get('total_books', 0))
            
            with col2:
                st.metric("📖 Available", summary.get('available_books', 0))
            
            with col3:
                st.metric("🔄 Borrowed", summary.get('borrowed_books', 0))
            
            with col4:
                st.metric("👥 Employees", summary.get('total_employees', 0))
            
            st.divider()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("🔴 Overdue Books", alerts.get('overdue_books', 0))
            
            with col2:
                st.metric("🟡 Due Soon", alerts.get('due_soon', 0))
            
        except Exception as e:
            st.error(f"Error loading dashboard: {str(e)}")
    
    # Tab 3: Borrowed Books
    with tab3:
        st.header("📖 Currently Borrowed Books")
        
        try:
            borrowed = st.session_state.agent.api_client.get_borrowed_books()
            
            if borrowed:
                df_data = []
                for book in borrowed:
                    df_data.append({
                        "Book Title": book['title'],
                        "Borrower": book['employee_name'],
                        "Borrow Date": book['borrow_date'],
                        "Due Date": book['due_date'],
                        "Status": book['due_status'],
                        "Days Left": book['days_remaining']
                    })
                
                df = pd.DataFrame(df_data)
                
                # Color code by status
                def color_status(val):
                    if val == 'overdue':
                        return 'background-color: #ffcccc'
                    elif val == 'due_soon':
                        return 'background-color: #ffffcc'
                    else:
                        return 'background-color: #ccffcc'
                
                st.dataframe(
                    df.style.applymap(color_status, subset=['Status']),
                    use_container_width=True
                )
            else:
                st.info("✓ No books currently borrowed!")
        
        except Exception as e:
            st.error(f"Error: {str(e)}")
    
    # Tab 4: Overdue Books
    with tab4:
        st.header("⏰ Overdue Books")
        
        try:
            overdue = st.session_state.agent.api_client.get_overdue_books()
            
            if overdue:
                for book in overdue:
                    with st.container():
                        col1, col2 = st.columns([3, 1])
                        
                        with col1:
                            st.write(f"📖 **{book['book_title']}**")
                            st.write(f"👤 Borrowed by: {book['employee_name']}")
                            st.write(f"📧 Email: {book['email']}")
                            st.write(f"📅 Due: {book['due_date']}")
                        
                        with col2:
                            if book['days_overdue'] > 7:
                                st.error(f"🔴 {book['days_overdue']} days\nOVERDUE")
                            elif book['days_overdue'] > 3:
                                st.warning(f"🟠 {book['days_overdue']} days\nOVERDUE")
                            else:
                                st.info(f"🟡 {book['days_overdue']} days\nOVERDUE")
                        
                        st.divider()
            else:
                st.success("✓ No overdue books!")
        
        except Exception as e:
            st.error(f"Error: {str(e)}")
    
    # Tab 5: Search
    with tab5:
        st.header("🔍 Search Books")
        
        search_query = st.text_input("Search for books:")
        
        if search_query:
            try:
                results = st.session_state.agent.api_client.search_books(search_query)
                
                if results:
                    for book in results:
                        with st.container():
                            col1, col2 = st.columns([3, 1])
                            
                            with col1:
                                st.write(f"📖 **{book['title']}**")
                                st.write(f"✍️ Author: {book['author']}")
                                st.write(f"🏷️ Genre: {book['genre']}")
                            
                            with col2:
                                st.metric("Available", book['available_copies'])
                            
                            st.divider()
                else:
                    st.info(f"No books found for '{search_query}'")
            
            except Exception as e:
                st.error(f"Error: {str(e)}")