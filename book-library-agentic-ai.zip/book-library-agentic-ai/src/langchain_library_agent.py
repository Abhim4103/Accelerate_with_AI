"""
LangChain-based Library Management Agent
Uses Groq or Google Generative AI (Free & Fast)
"""

from langchain_groq import ChatGroq
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage
import requests
import json
from typing import Dict, List, Optional
from datetime import datetime
from src.utils import print_info, print_error, print_warning, print_success

class LibraryAPIClient:
    """Client for Library REST API"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
    
    def _request(self, endpoint: str, method: str = "GET", data: Dict = None) -> Optional[Dict]:
        """Make API request"""
        try:
            url = f"{self.base_url}{endpoint}"
            if method == "GET":
                response = requests.get(url, headers=self.headers, timeout=5)
            else:
                response = requests.post(url, json=data, headers=self.headers, timeout=5)
            
            return response.json() if response.status_code in [200, 201] else None
        except:
            return None
    
    def get_all_books(self) -> List[Dict]:
        result = self._request("/api/books")
        return result.get('data', []) if result else []
    
    def get_borrowed_books(self) -> List[Dict]:
        result = self._request("/api/borrowed")
        return result.get('data', []) if result else []
    
    def get_employee_books(self, emp_id: str) -> Dict:
        result = self._request(f"/api/employees/{emp_id}/borrowed")
        return result.get('data', {}) if result else {}
    
    def get_overdue_books(self) -> List[Dict]:
        result = self._request("/api/borrowed/overdue")
        return result.get('data', []) if result else []
    
    def get_due_soon(self) -> List[Dict]:
        result = self._request("/api/borrowed/due-soon")
        return result.get('data', []) if result else []
    
    def get_stats(self) -> Dict:
        result = self._request("/api/stats/dashboard")
        return result.get('data', {}) if result else {}
    
    def get_employees(self) -> List[Dict]:
        result = self._request("/api/employees")
        return result.get('data', []) if result else []
    
    def search_books(self, keyword: str) -> List[Dict]:
        result = self._request(f"/api/books/search?q={keyword}")
        return result.get('data', []) if result else []
    
    def borrow_book(self, emp_id: str, book_id: str) -> Dict:
        return self._request("/api/borrow", method="POST", 
                           data={"employee_id": emp_id, "book_id": book_id}) or {}
    
    def return_book(self, emp_id: str, book_id: str) -> Dict:
        return self._request("/api/return", method="POST",
                           data={"employee_id": emp_id, "book_id": book_id}) or {}


class LangChainLibraryAgent:
    """LangChain-based Library Management Agent"""
    
    def __init__(self, provider: str = "groq", api_key: str = ""):
        """
        Initialize Agent
        
        Args:
            provider: "groq" or "google"
            api_key: Your API key
        """
        self.provider = provider
        self.api_key = api_key
        self.api_client = LibraryAPIClient()
        self.memory = ConversationBufferMemory()
        self.llm = self._init_llm()
        self.tools = self._setup_tools()
    
    def _init_llm(self):
        """Initialize LLM based on provider"""
        if self.provider == "groq":
            return ChatGroq(
                temperature=0.7,
                groq_api_key=self.api_key,
                model_name="mixtral-8x7b-32768"
            )
        elif self.provider == "google":
            return ChatGoogleGenerativeAI(
                model="gemini-pro",
                google_api_key=self.api_key,
                temperature=0.7
            )
        else:
            print_warning("Using Groq as default")
            return ChatGroq(
                temperature=0.7,
                groq_api_key=self.api_key,
                model_name="mixtral-8x7b-32768"
            )
    
    def _setup_tools(self) -> Dict:
        """Setup available tools"""
        return {
            "get_all_books": self._tool_get_all_books,
            "get_borrowed_books": self._tool_get_borrowed_books,
            "get_employee_books": self._tool_get_employee_books,
            "get_overdue_books": self._tool_get_overdue_books,
            "get_due_soon": self._tool_get_due_soon,
            "search_books": self._tool_search_books,
            "get_stats": self._tool_get_stats,
            "borrow_book": self._tool_borrow_book,
            "return_book": self._tool_return_book,
        }
    
    # Tool implementations
    def _tool_get_all_books(self) -> str:
        books = self.api_client.get_all_books()
        return f"Found {len(books)} books. Sample: " + \
               ", ".join([f"{b['title']} by {b['author']}" for b in books[:3]])
    
    def _tool_get_borrowed_books(self) -> str:
        books = self.api_client.get_borrowed_books()
        if not books:
            return "No books currently borrowed."
        
        details = []
        for b in books[:5]:
            details.append(
                f"- {b['title']} (borrowed by {b['employee_name']}, "
                f"due {b['due_date']}, status: {b['due_status']})"
            )
        return "Currently borrowed books:\n" + "\n".join(details)
    
    def _tool_get_employee_books(self, emp_id: str = "") -> str:
        if not emp_id:
            return "Please provide employee ID"
        
        data = self.api_client.get_employee_books(emp_id)
        if not data or 'borrowed_books' not in data:
            return f"Employee {emp_id} not found or has no borrowed books"
        
        books = data.get('borrowed_books', [])
        if not books:
            return f"{data['employee']['name']} is not holding any books"
        
        details = []
        for b in books:
            details.append(
                f"- {b['title']} (due {b['due_date']}, {b['days_remaining']} days remaining)"
            )
        return f"{data['employee']['name']}'s books:\n" + "\n".join(details)
    
    def _tool_get_overdue_books(self) -> str:
        books = self.api_client.get_overdue_books()
        if not books:
            return "No overdue books! 🎉"
        
        details = []
        for b in books[:5]:
            details.append(
                f"- {b['book_title']} (borrowed by {b['employee_name']}, "
                f"{b['days_overdue']} days overdue)"
            )
        return f"⚠️  OVERDUE BOOKS ({len(books)}):\n" + "\n".join(details)
    
    def _tool_get_due_soon(self) -> str:
        books = self.api_client.get_due_soon()
        if not books:
            return "No books due soon!"
        
        details = []
        for b in books[:5]:
            details.append(
                f"- {b['title']} (due {b['due_date']}, {b['days_remaining']} days)"
            )
        return f"📌 Books due within 3 days:\n" + "\n".join(details)
    
    def _tool_search_books(self, keyword: str = "") -> str:
        if not keyword:
            return "Please provide a search keyword"
        
        books = self.api_client.search_books(keyword)
        if not books:
            return f"No books found for '{keyword}'"
        
        details = []
        for b in books[:5]:
            details.append(f"- {b['title']} by {b['author']} ({b['available_copies']} available)")
        return f"Search results for '{keyword}':\n" + "\n".join(details)
    
    def _tool_get_stats(self) -> str:
        stats = self.api_client.get_stats()
        if not stats:
            return "Could not fetch statistics"
        
        summary = stats.get('summary', {})
        alerts = stats.get('alerts', {})
        
        return f"""
Library Statistics:
- Total Books: {summary.get('total_books', 0)}
- Available: {summary.get('available_books', 0)}
- Borrowed: {summary.get('borrowed_books', 0)}
- Employees: {summary.get('total_employees', 0)}

Alerts:
- Overdue: {alerts.get('overdue_books', 0)}
- Due Soon: {alerts.get('due_soon', 0)}
"""
    
    def _tool_borrow_book(self, emp_id: str = "", book_id: str = "") -> str:
        if not emp_id or not book_id:
            return "Please provide employee ID and book ID"
        
        result = self.api_client.borrow_book(emp_id, book_id)
        return result.get('message', 'Failed to borrow book')
    
    def _tool_return_book(self, emp_id: str = "", book_id: str = "") -> str:
        if not emp_id or not book_id:
            return "Please provide employee ID and book ID"
        
        result = self.api_client.return_book(emp_id, book_id)
        return result.get('message', 'Failed to return book')
    
    def get_library_context(self) -> str:
        """Get current library context"""
        stats = self.api_client.get_stats()
        summary = stats.get('summary', {}) if stats else {}
        
        context = f"""
Current Library Status:
- Total Books: {summary.get('total_books', 0)}
- Available: {summary.get('available_books', 0)}
- Borrowed: {summary.get('borrowed_books', 0)}
- Total Employees: {summary.get('total_employees', 0)}

You have access to the following tools:
1. get_all_books - List all books in library
2. get_borrowed_books - Show all currently borrowed books with due dates
3. get_employee_books - Check specific employee's borrowed books
4. get_overdue_books - Show overdue books
5. get_due_soon - Show books due within 3 days
6. search_books - Search for books by keyword
7. get_stats - Get library statistics
8. borrow_book - Borrow a book
9. return_book - Return a book

When user asks questions, use these tools to provide accurate information.
"""
        return context
    
    def process_query(self, user_query: str) -> str:
        """Process user query and generate response"""
        try:
            context = self.get_library_context()
            
            prompt = f"""{context}

User Query: {user_query}

Based on the user's query, determine which tools to use and provide a helpful response.
If the user wants to know about books, use search_books or get_all_books.
If they ask about overdue books, use get_overdue_books.
If they ask about a specific employee, use get_employee_books.
Always provide specific, accurate information."""
            
            response = self.llm.invoke([HumanMessage(content=prompt)])
            return response.content
        
        except Exception as e:
            print_error(f"Error processing query: {str(e)}")
            return "I encountered an error processing your request."
    
    def chat(self, user_message: str) -> str:
        """Chat interface"""
        self.memory.chat_memory.add_user_message(user_message)
        response = self.process_query(user_message)
        self.memory.chat_memory.add_ai_message(response)
        return response