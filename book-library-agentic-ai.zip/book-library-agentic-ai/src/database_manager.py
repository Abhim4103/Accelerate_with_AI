import sqlite3
import pandas as pd
from datetime import datetime
from typing import List, Dict, Optional
from config.settings import (
    DATABASE_PATH, BOOKS_CSV, EMPLOYEES_CSV, 
    BORROWERS_CSV, PROVIDERS_CSV
)
from src.utils import print_success, print_error, print_warning

class DatabaseManager:
    """Manages SQLite database operations"""
    
    def __init__(self):
        self.db_path = DATABASE_PATH
        self.init_database()
        self.load_initial_data()
    
    def init_database(self):
        """Initialize database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Books table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                book_id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                isbn TEXT UNIQUE,
                genre TEXT,
                total_copies INTEGER,
                available_copies INTEGER,
                provider_id TEXT,
                added_date TEXT,
                FOREIGN KEY (provider_id) REFERENCES providers(provider_id)
            )
        ''')
        
        # Employees table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                employee_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                department TEXT,
                email TEXT,
                phone TEXT,
                joining_date TEXT
            )
        ''')
        
        # Borrowers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS borrowers (
                borrow_id TEXT PRIMARY KEY,
                employee_id TEXT NOT NULL,
                book_id TEXT NOT NULL,
                borrow_date TEXT,
                due_date TEXT,
                return_date TEXT,
                status TEXT,
                FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
                FOREIGN KEY (book_id) REFERENCES books(book_id)
            )
        ''')
        
        # Providers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS providers (
                provider_id TEXT PRIMARY KEY,
                provider_name TEXT NOT NULL,
                provider_type TEXT,
                contact_email TEXT,
                phone TEXT,
                address TEXT,
                city TEXT,
                country TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
        print_success("Database initialized successfully")
    
    def load_initial_data(self):
        """Load initial data from CSV files"""
        try:
            # Load providers first (referenced by books)
            if self._table_is_empty('providers'):
                providers_df = pd.read_csv(PROVIDERS_CSV)
                providers_df.to_sql('providers', sqlite3.connect(self.db_path), if_exists='append', index=False)
                print_success(f"Loaded {len(providers_df)} providers")
            
            # Load books
            if self._table_is_empty('books'):
                books_df = pd.read_csv(BOOKS_CSV)
                books_df.to_sql('books', sqlite3.connect(self.db_path), if_exists='append', index=False)
                print_success(f"Loaded {len(books_df)} books")
            
            # Load employees
            if self._table_is_empty('employees'):
                employees_df = pd.read_csv(EMPLOYEES_CSV)
                employees_df.to_sql('employees', sqlite3.connect(self.db_path), if_exists='append', index=False)
                print_success(f"Loaded {len(employees_df)} employees")
            
            # Load borrowers
            if self._table_is_empty('borrowers'):
                borrowers_df = pd.read_csv(BORROWERS_CSV)
                borrowers_df.to_sql('borrowers', sqlite3.connect(self.db_path), if_exists='append', index=False)
                print_success(f"Loaded {len(borrowers_df)} borrowing records")
        
        except Exception as e:
            print_error(f"Error loading initial data: {str(e)}")
    
    def _table_is_empty(self, table_name: str) -> bool:
        """Check if table is empty"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        conn.close()
        return count == 0
    
    def get_all_books(self) -> List[Dict]:
        """Get all books"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM books')
        books = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return books
    
    def get_book_by_id(self, book_id: str) -> Optional[Dict]:
        """Get book by ID"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM books WHERE book_id = ?', (book_id,))
        book = cursor.fetchone()
        conn.close()
        return dict(book) if book else None
    
    def search_books(self, keyword: str) -> List[Dict]:
        """Search books by title or author"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        keyword = f"%{keyword}%"
        cursor.execute('''
            SELECT * FROM books 
            WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?
        ''', (keyword, keyword, keyword))
        books = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return books
    
    def get_all_employees(self) -> List[Dict]:
        """Get all employees"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM employees')
        employees = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return employees
    
    def get_employee_by_id(self, employee_id: str) -> Optional[Dict]:
        """Get employee by ID"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM employees WHERE employee_id = ?', (employee_id,))
        employee = cursor.fetchone()
        conn.close()
        return dict(employee) if employee else None
    
    def get_employee_books(self, employee_id: str) -> List[Dict]:
        """Get books borrowed by employee"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('''
            SELECT b.book_id, b.title, b.author, br.borrow_date, br.due_date, br.status
            FROM borrowers br
            JOIN books b ON br.book_id = b.book_id
            WHERE br.employee_id = ? AND br.status = 'borrowed'
            ORDER BY br.due_date
        ''', (employee_id,))
        books = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return books
    
    def borrow_book(self, employee_id: str, book_id: str, borrow_days: int = 14) -> Dict:
        """Borrow a book"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if employee exists
            cursor.execute('SELECT * FROM employees WHERE employee_id = ?', (employee_id,))
            if not cursor.fetchone():
                return {"status": "error", "message": "Employee not found"}
            
            # Check if book exists and has copies
            cursor.execute('SELECT available_copies FROM books WHERE book_id = ?', (book_id,))
            book = cursor.fetchone()
            if not book or book[0] <= 0:
                return {"status": "error", "message": "Book not available"}
            
            # Create borrow record
            from datetime import datetime, timedelta
            borrow_date = datetime.now().strftime("%Y-%m-%d")
            due_date = (datetime.now() + timedelta(days=borrow_days)).strftime("%Y-%m-%d")
            borrow_id = f"BR{int(datetime.now().timestamp())}"
            
            cursor.execute('''
                INSERT INTO borrowers (borrow_id, employee_id, book_id, borrow_date, due_date, status)
                VALUES (?, ?, ?, ?, ?, 'borrowed')
            ''', (borrow_id, employee_id, book_id, borrow_date, due_date))
            
            # Update available copies
            cursor.execute('''
                UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?
            ''', (book_id,))
            
            conn.commit()
            return {"status": "success", "message": f"Book borrowed successfully. Due date: {due_date}"}
        
        except Exception as e:
            return {"status": "error", "message": str(e)}
        finally:
            conn.close()
    
    def return_book(self, employee_id: str, book_id: str) -> Dict:
        """Return a book"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Find active borrow record
            cursor.execute('''
                SELECT borrow_id FROM borrowers 
                WHERE employee_id = ? AND book_id = ? AND status = 'borrowed'
            ''', (employee_id, book_id))
            borrow = cursor.fetchone()
            
            if not borrow:
                return {"status": "error", "message": "No active borrowing record found"}
            
            return_date = datetime.now().strftime("%Y-%m-%d")
            cursor.execute('''
                UPDATE borrowers SET status = 'returned', return_date = ? 
                WHERE borrow_id = ?
            ''', (return_date, borrow[0]))
            
            # Update available copies
            cursor.execute('''
                UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?
            ''', (book_id,))
            
            conn.commit()
            return {"status": "success", "message": "Book returned successfully"}
        
        except Exception as e:
            return {"status": "error", "message": str(e)}
        finally:
            conn.close()
    
    def get_all_providers(self) -> List[Dict]:
        """Get all book providers"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM providers')
        providers = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return providers
    
    def get_provider_books(self, provider_id: str) -> List[Dict]:
        """Get all books from a provider"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM books WHERE provider_id = ?
        ''', (provider_id,))
        books = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return books
    
    def get_overdue_books(self) -> List[Dict]:
        """Get all overdue books"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        today = datetime.now().strftime("%Y-%m-%d")
        cursor.execute('''
            SELECT b.title, e.name, e.email, br.due_date, 
                   (julianday(?) - julianday(br.due_date)) as days_overdue
            FROM borrowers br
            JOIN books b ON br.book_id = b.book_id
            JOIN employees e ON br.employee_id = e.employee_id
            WHERE br.status = 'borrowed' AND br.due_date < ?
            ORDER BY br.due_date
        ''', (today, today))
        overdue = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return overdue
    
    def get_library_stats(self) -> Dict:
        """Get library statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM books')
        total_books = cursor.fetchone()[0]
        
        cursor.execute('SELECT SUM(available_copies) FROM books')
        available_books = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT COUNT(*) FROM borrowers WHERE status = "borrowed"')
        borrowed_books = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM employees')
        total_employees = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM providers')
        total_providers = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "total_books": total_books,
            "available_books": available_books,
            "borrowed_books": borrowed_books,
            "total_employees": total_employees,
            "total_providers": total_providers
        }