"""
AI-Powered Chatbot with API Integration
Uses open-source LLM to answer library queries
"""

import requests
import json
from typing import Dict, List, Optional
from src.llm_service import LocalLLMChatbot
from src.utils import (
    print_header, print_success, print_error, print_info, 
    print_warning, print_table, Colors
)

class APIClient:
    """Client for Library API"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
    
    def _make_request(self, endpoint: str, method: str = "GET", data: Dict = None) -> Optional[Dict]:
        """Make API request"""
        try:
            url = f"{self.base_url}{endpoint}"
            
            if method == "GET":
                response = requests.get(url, headers=self.headers, timeout=5)
            elif method == "POST":
                response = requests.post(url, json=data, headers=self.headers, timeout=5)
            else:
                return None
            
            if response.status_code in [200, 201]:
                return response.json()
            else:
                return None
        
        except requests.exceptions.ConnectionError:
            print_error("Cannot connect to API server. Make sure api_main.py is running.")
            return None
        except Exception as e:
            print_error(f"API Error: {str(e)}")
            return None
    
    def get_all_books(self) -> List[Dict]:
        """Get all books"""
        result = self._make_request("/api/books")
        return result.get('data', []) if result else []
    
    def get_available_books(self) -> List[Dict]:
        """Get available books"""
        result = self._make_request("/api/books/available")
        return result.get('data', []) if result else []
    
    def search_books(self, keyword: str) -> List[Dict]:
        """Search books"""
        result = self._make_request(f"/api/books/search?q={keyword}")
        return result.get('data', []) if result else []
    
    def get_employees(self) -> List[Dict]:
        """Get all employees"""
        result = self._make_request("/api/employees")
        return result.get('data', []) if result else []
    
    def get_employee_borrowed_books(self, employee_id: str) -> Dict:
        """Get employee's borrowed books"""
        result = self._make_request(f"/api/employees/{employee_id}/borrowed")
        return result.get('data', {}) if result else {}
    
    def get_all_borrowed_books(self) -> List[Dict]:
        """Get all borrowed books"""
        result = self._make_request("/api/borrowed")
        return result.get('data', []) if result else []
    
    def get_overdue_books(self) -> List[Dict]:
        """Get overdue books"""
        result = self._make_request("/api/borrowed/overdue")
        return result.get('data', []) if result else []
    
    def get_due_soon_books(self) -> List[Dict]:
        """Get books due soon"""
        result = self._make_request("/api/borrowed/due-soon")
        return result.get('data', []) if result else []
    
    def get_stats(self) -> Dict:
        """Get library statistics"""
        result = self._make_request("/api/stats/dashboard")
        return result.get('data', {}) if result else {}
    
    def borrow_book(self, employee_id: str, book_id: str) -> Dict:
        """Borrow a book"""
        data = {"employee_id": employee_id, "book_id": book_id}
        result = self._make_request("/api/borrow", method="POST", data=data)
        return result if result else {"status": "error", "message": "Failed to borrow book"}
    
    def return_book(self, employee_id: str, book_id: str) -> Dict:
        """Return a book"""
        data = {"employee_id": employee_id, "book_id": book_id}
        result = self._make_request("/api/return", method="POST", data=data)
        return result if result else {"status": "error", "message": "Failed to return book"}


class AILibraryChatbot:
    """AI-Powered Library Chatbot"""
    
    def __init__(self, api_base_url: str = "http://localhost:5000", 
                 llm_base_url: str = "http://localhost:11434",
                 llm_model: str = "mistral"):
        self.api = APIClient(api_base_url)
        self.llm = LocalLLMChatbot(llm_model, llm_base_url)
        self.llm_model = llm_model
        self.commands = self._initialize_commands()
    
    def _initialize_commands(self) -> dict:
        """Initialize commands"""
        return {
            "help": self.show_help,
            "books": self.show_books,
            "available": self.show_available_books,
            "borrowed": self.show_borrowed_books,
            "employees": self.show_employees,
            "employee": self.show_employee_details,
            "overdue": self.show_overdue_books,
            "due-soon": self.show_due_soon_books,
            "stats": self.show_statistics,
            "search": self.search_books,
            "borrow": self.borrow_book_cmd,
            "return": self.return_book_cmd,
            "ask": self.ask_ai,
            "clear": self.clear_screen,
            "exit": self.exit_chatbot,
        }
    
    def show_welcome_message(self):
        """Show welcome message"""
        print_header("🤖 AI-POWERED BOOK LIBRARY CHATBOT")
        print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                   Welcome to AI Library Assistant                            ║
║                                                                              ║
║  This chatbot uses open-source AI (via Ollama) to help you manage the       ║
║  company library. You can:                                                  ║
║                                                                              ║
║  • Ask natural language questions about books and borrowing                 ║
║  • View available books and borrowed books with due dates                   ║
║  • Check overdue books and statistics                                       ║
║  • Borrow and return books                                                  ║
║                                                                              ║
║  Type 'help' for commands or just ask a question in natural language        ║
║  Type 'exit' to quit                                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
        """)
        
        # Check LLM availability
        if self.llm.is_available():
            print_success(f"✓ AI Model '{self.llm_model}' is ready!")
        else:
            print_warning("⚠️  AI Model not available. Install Ollama from https://ollama.ai")
            print_info("Fallback mode: Using command-based responses")
    
    def show_help(self, *args):
        """Show help message"""
        print_header("Available Commands", level=2)
        help_text = [
            ["help", "Show this help message"],
            ["books", "Show all books in library"],
            ["available", "Show only available books"],
            ["borrowed", "Show all currently borrowed books with due dates"],
            ["employees", "Show all employees"],
            ["employee <ID>", "Show employee details and their borrowed books"],
            ["overdue", "Show overdue books"],
            ["due-soon", "Show books due within 3 days"],
            ["stats", "Show library statistics"],
            ["search <keyword>", "Search for books"],
            ["borrow <EMP> <BOOK>", "Borrow a book"],
            ["return <EMP> <BOOK>", "Return a book"],
            ["ask <question>", "Ask AI a natural language question"],
            ["clear", "Clear screen"],
            ["exit", "Exit chatbot"],
        ]
        print_table(help_text, ["Command", "Description"])
    
    def show_books(self, *args):
        """Show all books"""
        print_header("All Books in Library", level=2)
        books = self.api.get_all_books()
        
        if books:
            table_data = []
            for book in books:
                table_data.append([
                    book['book_id'],
                    book['title'][:35],
                    book['author'][:20],
                    book['genre'],
                    book['available_copies'],
                    book['total_copies']
                ])
            print_table(table_data, ["ID", "Title", "Author", "Genre", "Avail", "Total"])
        else:
            print_warning("No books found or API not available")
    
    def show_available_books(self, *args):
        """Show available books"""
        print_header("Available Books", level=2)
        books = self.api.get_available_books()
        
        if books:
            table_data = []
            for book in books:
                table_data.append([
                    book['book_id'],
                    book['title'][:35],
                    book['author'][:20],
                    book['genre'],
                    book['available_copies']
                ])
            print_table(table_data, ["ID", "Title", "Author", "Genre", "Available"])
            print_info(f"Total available: {len(books)} books")
        else:
            print_warning("No available books found")
    
    def show_borrowed_books(self, *args):
        """Show all borrowed books with due dates"""
        print_header("Currently Borrowed Books (with Due Dates)", level=2)
        books = self.api.get_all_borrowed_books()
        
        if books:
            table_data = []
            for book in books:
                status_icon = "🔴" if book['due_status'] == 'overdue' else "🟡" if book['due_status'] == 'due_soon' else "🟢"
                table_data.append([
                    status_icon,
                    book['title'][:25],
                    book['employee_name'][:20],
                    book['borrow_date'],
                    book['due_date'],
                    book['due_status'],
                    str(book['days_remaining']) if book['days_remaining'] >= 0 else f"-{abs(book['days_remaining'])}"
                ])
            print_table(table_data, ["Status", "Book Title", "Borrower", "Borrow Date", "Due Date", "Status", "Days Left"])
            print_info(f"Total borrowed: {len(books)} books")
        else:
            print_success("No borrowed books found!")
    
    def show_employees(self, *args):
        """Show all employees"""
        print_header("All Employees", level=2)
        employees = self.api.get_employees()
        
        if employees:
            table_data = []
            for emp in employees:
                table_data.append([
                    emp['employee_id'],
                    emp['name'][:25],
                    emp['department'],
                    emp['email'][:25]
                ])
            print_table(table_data, ["ID", "Name", "Department", "Email"])
            print_info(f"Total employees: {len(employees)}")
        else:
            print_warning("No employees found")
    
    def show_employee_details(self, *args):
        """Show employee details"""
        emp_id = " ".join(args) if args else input("Enter Employee ID (e.g., EMP001): ").strip().upper()
        
        if not emp_id:
            print_warning("Please provide an employee ID")
            return
        
        print_header(f"Employee Details: {emp_id}", level=2)
        data = self.api.get_employee_borrowed_books(emp_id)
        
        if data and 'employee' in data:
            emp = data['employee']
            emp_info = [
                ["Employee ID", emp['employee_id']],
                ["Name", emp['name']],
                ["Department", emp['department']],
                ["Email", emp['email']],
            ]
            print_table(emp_info, ["Field", "Value"])
            
            books = data.get('borrowed_books', [])
            if books:
                print_header(f"Books Held by {emp['name']}", level=2)
                table_data = []
                for book in books:
                    table_data.append([
                        book['title'][:30],
                        book['author'][:20],
                        book['borrow_date'],
                        book['due_date'],
                        book['due_status'],
                        str(book['days_remaining'])
                    ])
                print_table(table_data, ["Title", "Author", "Borrow Date", "Due Date", "Status", "Days Left"])
            else:
                print_info(f"{emp['name']} is not holding any books")
        else:
            print_error(f"Employee {emp_id} not found")
    
    def show_overdue_books(self, *args):
        """Show overdue books"""
        print_header("Overdue Books", level=2)
        books = self.api.get_overdue_books()
        
        if books:
            table_data = []
            for book in books:
                urgency = "🔴 CRITICAL" if book['days_overdue'] > 7 else "🟠 HIGH" if book['days_overdue'] > 3 else "🟡 MEDIUM"
                table_data.append([
                    urgency,
                    book['book_title'][:25],
                    book['employee_name'][:20],
                    book['due_date'],
                    f"{book['days_overdue']} days"
                ])
            print_table(table_data, ["Urgency", "Book", "Borrower", "Due Date", "Overdue"])
            print_warning(f"⚠️  {len(books)} overdue book(s)")
        else:
            print_success("No overdue books!")
    
    def show_due_soon_books(self, *args):
        """Show books due soon"""
        print_header("Books Due Within 3 Days", level=2)
        books = self.api.get_due_soon_books()
        
        if books:
            table_data = []
            for book in books:
                table_data.append([
                    book['title'][:30],
                    book['employee_name'][:20],
                    book['due_date'],
                    f"{book['days_remaining']} days"
                ])
            print_table(table_data, ["Book Title", "Borrower", "Due Date", "Days Remaining"])
            print_info(f"📌 {len(books)} book(s) due soon")
        else:
            print_success("No books due soon!")
    
    def show_statistics(self, *args):
        """Show statistics"""
        print_header("Library Statistics Dashboard", level=2)
        stats = self.api.get_stats()
        
        if stats:
            if 'summary' in stats:
                summary = stats['summary']
                summary_data = [
                    ["Total Books", summary.get('total_books', 0)],
                    ["Available Books", summary.get('available_books', 0)],
                    ["Borrowed Books", summary.get('borrowed_books', 0)],
                    ["Total Employees", summary.get('total_employees', 0)],
                    ["Total Providers", summary.get('total_providers', 0)],
                ]
                print_table(summary_data, ["Metric", "Count"])
            
            if 'alerts' in stats:
                print_header("Alerts", level=2)
                alerts = stats['alerts']
                alerts_data = [
                    ["Overdue Books", alerts.get('overdue_books', 0)],
                    ["Due Soon", alerts.get('due_soon', 0)],
                ]
                print_table(alerts_data, ["Alert Type", "Count"])
            
            if 'top_books' in stats and stats['top_books']:
                print_header("Top 5 Most Borrowed Books", level=2)
                books_data = []
                for book in stats['top_books']:
                    books_data.append([book['title'][:30], book['borrow_count']])
                print_table(books_data, ["Title", "Times Borrowed"])
        else:
            print_warning("Could not fetch statistics")
    
    def search_books(self, *args):
        """Search for books"""
        keyword = " ".join(args) if args else input("Enter search keyword: ").strip()
        
        if not keyword:
            print_warning("Please provide a search keyword")
            return
        
        print_header(f"Search Results for '{keyword}'", level=2)
        books = self.api.search_books(keyword)
        
        if books:
            table_data = []
            for book in books:
                table_data.append([
                    book['book_id'],
                    book['title'][:30],
                    book['author'][:20],
                    book['available_copies'],
                    book['total_copies']
                ])
            print_table(table_data, ["ID", "Title", "Author", "Available", "Total"])
            print_info(f"Found {len(books)} book(s)")
        else:
            print_warning(f"No books found for '{keyword}'")
    
    def borrow_book_cmd(self, *args):
        """Borrow a book"""
        if len(args) >= 2:
            emp_id = args[0].upper()
            book_id = args[1].upper()
        else:
            emp_id = input("Enter Employee ID (e.g., EMP001): ").strip().upper()
            book_id = input("Enter Book ID (e.g., B001): ").strip().upper()
        
        if not emp_id or not book_id:
            print_warning("Please provide both Employee ID and Book ID")
            return
        
        print_header("Processing Book Borrowing", level=2)
        result = self.api.borrow_book(emp_id, book_id)
        
        if result.get('status') == 'success':
            print_success(result.get('message', 'Book borrowed successfully'))
        else:
            print_error(result.get('message', 'Failed to borrow book'))
    
    def return_book_cmd(self, *args):
        """Return a book"""
        if len(args) >= 2:
            emp_id = args[0].upper()
            book_id = args[1].upper()
        else:
            emp_id = input("Enter Employee ID (e.g., EMP001): ").strip().upper()
            book_id = input("Enter Book ID (e.g., B001): ").strip().upper()
        
        if not emp_id or not book_id:
            print_warning("Please provide both Employee ID and Book ID")
            return
        
        print_header("Processing Book Return", level=2)
        result = self.api.return_book(emp_id, book_id)
        
        if result.get('status') == 'success':
            print_success(result.get('message', 'Book returned successfully'))
        else:
            print_error(result.get('message', 'Failed to return book'))
    
    def ask_ai(self, *args):
        """Ask AI a question"""
        question = " ".join(args) if args else input("Ask me anything about the library: ").strip()
        
        if not question:
            print_warning("Please ask a question")
            return
        
        if not self.llm.is_available():
            print_error("AI model not available. Please install Ollama first.")
            print_info("Download from: https://ollama.ai")
            return
        
        print_header("AI Response", level=2)
        print_info("Thinking...")
        
        # Get library context
        books = self.api.get_all_books()[:3]
        borrowed = self.api.get_all_borrowed_books()[:3]
        employees = self.api.get_employees()[:2]
        
        context = self.llm.llm.format_library_context({
            'books': books,
            'borrowed_books': borrowed,
            'employees': employees
        })
        
        # Get AI response
        response = self.llm.get_response(question, context)
        
        print(f"\n{Colors.SUCCESS}{response}{Colors.RESET}\n")
    
    def clear_screen(self, *args):
        """Clear screen"""
        import os
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def exit_chatbot(self, *args):
        """Exit chatbot"""
        print("\n")
        print_header("Thank You!", level=2)
        print("👋 Thank you for using AI Library Chatbot!")
        print("Have a great day!\n")
        exit(0)
    
    def run(self):
        """Run the chatbot"""
        self.show_welcome_message()
        
        while True:
            try:
                user_input = input("\n🤖 Library AI> ").strip()
                
                if not user_input:
                    continue
                
                # Parse command
                parts = user_input.split(maxsplit=1)
                command = parts[0].lower()
                args = parts[1].split() if len(parts) > 1 else []
                
                if command in self.commands:
                    self.commands[command](*args)
                else:
                    # Try as natural language query
                    print_info("Processing natural language query...")
                    self.ask_ai(user_input)
            
            except KeyboardInterrupt:
                self.exit_chatbot()
            except Exception as e:
                print_error(f"Error: {str(e)}")