import json
from typing import Dict, List, Any, Callable
from datetime import datetime
from src.database_manager import DatabaseManager
from src.utils import print_info, print_warning, print_error, format_date

class AgenticAI:
    """AI Agent for library management"""
    
    def __init__(self):
        self.db = DatabaseManager()
        self.tools = self._initialize_tools()
        self.conversation_history = []
    
    def _initialize_tools(self) -> Dict[str, Callable]:
        """Initialize all available tools"""
        return {
            # Book tools
            "get_all_books": self._get_all_books,
            "search_books": self._search_books,
            "get_book_details": self._get_book_details,
            "get_available_books": self._get_available_books,
            
            # Employee tools
            "get_all_employees": self._get_all_employees,
            "get_employee_details": self._get_employee_details,
            "get_employee_books": self._get_employee_books,
            
            # Borrowing tools
            "borrow_book": self._borrow_book,
            "return_book": self._return_book,
            "get_borrowing_history": self._get_borrowing_history,
            
            # Provider tools
            "get_all_providers": self._get_all_providers,
            "get_provider_books": self._get_provider_books,
            
            # Statistics tools
            "get_library_stats": self._get_library_stats,
            "get_overdue_books": self._get_overdue_books,
        }
    
    # Book Tools
    def _get_all_books(self, **kwargs) -> str:
        """Get all books in library"""
        books = self.db.get_all_books()
        return json.dumps({
            "status": "success",
            "data": books,
            "count": len(books)
        })
    
    def _search_books(self, keyword: str = "", **kwargs) -> str:
        """Search for books by keyword"""
        if not keyword:
            return json.dumps({"status": "error", "message": "Keyword required"})
        
        books = self.db.search_books(keyword)
        return json.dumps({
            "status": "success",
            "data": books,
            "count": len(books),
            "keyword": keyword
        })
    
    def _get_book_details(self, book_id: str = "", **kwargs) -> str:
        """Get detailed information about a specific book"""
        if not book_id:
            return json.dumps({"status": "error", "message": "Book ID required"})
        
        book = self.db.get_book_by_id(book_id)
        if not book:
            return json.dumps({"status": "error", "message": "Book not found"})
        
        return json.dumps({
            "status": "success",
            "data": book
        })
    
    def _get_available_books(self, **kwargs) -> str:
        """Get all available books"""
        books = self.db.get_all_books()
        available = [b for b in books if b['available_copies'] > 0]
        return json.dumps({
            "status": "success",
            "data": available,
            "count": len(available)
        })
    
    # Employee Tools
    def _get_all_employees(self, **kwargs) -> str:
        """Get all employees"""
        employees = self.db.get_all_employees()
        return json.dumps({
            "status": "success",
            "data": employees,
            "count": len(employees)
        })
    
    def _get_employee_details(self, employee_id: str = "", **kwargs) -> str:
        """Get employee details"""
        if not employee_id:
            return json.dumps({"status": "error", "message": "Employee ID required"})
        
        employee = self.db.get_employee_by_id(employee_id)
        if not employee:
            return json.dumps({"status": "error", "message": "Employee not found"})
        
        return json.dumps({
            "status": "success",
            "data": employee
        })
    
    def _get_employee_books(self, employee_id: str = "", **kwargs) -> str:
        """Get books currently held by an employee"""
        if not employee_id:
            return json.dumps({"status": "error", "message": "Employee ID required"})
        
        books = self.db.get_employee_books(employee_id)
        return json.dumps({
            "status": "success",
            "data": books,
            "count": len(books),
            "employee_id": employee_id
        })
    
    # Borrowing Tools
    def _borrow_book(self, employee_id: str = "", book_id: str = "", due_days: int = 14, **kwargs) -> str:
        """Borrow a book for an employee"""
        if not employee_id or not book_id:
            return json.dumps({"status": "error", "message": "Employee ID and Book ID required"})
        
        result = self.db.borrow_book(employee_id, book_id, due_days)
        return json.dumps(result)
    
    def _return_book(self, employee_id: str = "", book_id: str = "", **kwargs) -> str:
        """Return a book"""
        if not employee_id or not book_id:
            return json.dumps({"status": "error", "message": "Employee ID and Book ID required"})
        
        result = self.db.return_book(employee_id, book_id)
        return json.dumps(result)
    
    def _get_borrowing_history(self, employee_id: str = "", **kwargs) -> str:
        """Get borrowing history of an employee"""
        if not employee_id:
            return json.dumps({"status": "error", "message": "Employee ID required"})
        
        conn = __import__('sqlite3').connect(__import__('config.settings', fromlist=['DATABASE_PATH']).DATABASE_PATH)
        conn.row_factory = __import__('sqlite3').Row
        cursor = conn.cursor()
        cursor.execute('''
            SELECT b.title, b.author, br.borrow_date, br.due_date, br.return_date, br.status
            FROM borrowers br
            JOIN books b ON br.book_id = b.book_id
            WHERE br.employee_id = ?
            ORDER BY br.borrow_date DESC
        ''', (employee_id,))
        history = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return json.dumps({
            "status": "success",
            "data": history,
            "count": len(history),
            "employee_id": employee_id
        })
    
    # Provider Tools
    def _get_all_providers(self, **kwargs) -> str:
        """Get all book providers"""
        providers = self.db.get_all_providers()
        return json.dumps({
            "status": "success",
            "data": providers,
            "count": len(providers)
        })
    
    def _get_provider_books(self, provider_id: str = "", **kwargs) -> str:
        """Get all books from a specific provider"""
        if not provider_id:
            return json.dumps({"status": "error", "message": "Provider ID required"})
        
        books = self.db.get_provider_books(provider_id)
        return json.dumps({
            "status": "success",
            "data": books,
            "count": len(books),
            "provider_id": provider_id
        })
    
    # Statistics Tools
    def _get_library_stats(self, **kwargs) -> str:
        """Get library statistics"""
        stats = self.db.get_library_stats()
        return json.dumps({
            "status": "success",
            "data": stats
        })
    
    def _get_overdue_books(self, **kwargs) -> str:
        """Get overdue books"""
        overdue = self.db.get_overdue_books()
        return json.dumps({
            "status": "success",
            "data": overdue,
            "count": len(overdue)
        })
    
    def process_request(self, user_input: str) -> str:
        """Process natural language request and route to appropriate tool"""
        user_input_lower = user_input.lower()
        
        # Add to conversation history
        self.conversation_history.append({
            "timestamp": datetime.now().isoformat(),
            "user": user_input
        })
        
        # Intent recognition and routing
        intents = {
            "list_books": ["list all books", "show books", "all books", "available books"],
            "search": ["search", "find", "look for", "find books"],
            "employee_books": ["my books", "books held", "what books", "employee books"],
            "borrow": ["borrow", "take", "checkout"],
            "return": ["return", "give back", "submit book"],
            "employees": ["employees", "show employees", "list employees"],
            "stats": ["statistics", "stats", "library stats", "overview"],
            "overdue": ["overdue", "late books", "pending returns"],
            "providers": ["providers", "suppliers", "publishers"],
        }
        
        # Match intent
        for intent, keywords in intents.items():
            if any(keyword in user_input_lower for keyword in keywords):
                return self._handle_intent(intent, user_input)
        
        return json.dumps({
            "status": "error",
            "message": "Unable to understand request. Try: list books, search [keyword], employee [ID], stats, etc."
        })
    
    def _handle_intent(self, intent: str, user_input: str) -> str:
        """Handle different intents"""
        
        if intent == "list_books":
            return self._get_available_books()
        
        elif intent == "search":
            # Extract keyword
            words = user_input.split()
            keyword = " ".join(words[words.index("search")+1:]) if "search" in user_input.lower() else ""
            return self._search_books(keyword=keyword)
        
        elif intent == "employee_books":
            # Extract employee ID
            words = user_input.split()
            for i, word in enumerate(words):
                if word.upper().startswith("EMP"):
                    employee_id = word.upper()
                    return self._get_employee_books(employee_id=employee_id)
            return json.dumps({"status": "error", "message": "Employee ID not found. Format: EMP###"})
        
        elif intent == "borrow":
            return json.dumps({"status": "info", "message": "Please provide: employee_id and book_id. Example: borrow EMP001 B001"})
        
        elif intent == "return":
            return json.dumps({"status": "info", "message": "Please provide: employee_id and book_id. Example: return EMP001 B001"})
        
        elif intent == "employees":
            return self._get_all_employees()
        
        elif intent == "stats":
            return self._get_library_stats()
        
        elif intent == "overdue":
            return self._get_overdue_books()
        
        elif intent == "providers":
            return self._get_all_providers()
        
        else:
            return json.dumps({"status": "error", "message": "Unknown intent"})
    
    def execute_tool(self, tool_name: str, **kwargs) -> str:
        """Execute a specific tool"""
        if tool_name in self.tools:
            try:
                result = self.tools[tool_name](**kwargs)
                return result
            except Exception as e:
                return json.dumps({"status": "error", "message": f"Tool execution error: {str(e)}"})
        else:
            return json.dumps({"status": "error", "message": f"Unknown tool: {tool_name}"})
    
    def get_available_tools(self) -> List[str]:
        """Get list of available tools"""
        return list(self.tools.keys())