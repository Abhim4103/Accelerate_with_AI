#!/usr/bin/env python3
"""
Book Library Management Agentic AI
Main entry point for the application
"""

import os
import sys
from src.chatbot import LibraryChatbot
from src.utils import print_header, print_success, create_logs_directory

def main():
    """Main function"""
    try:
        # Create necessary directories
        create_logs_directory()
        
        # Initialize and run chatbot
        chatbot = LibraryChatbot()
        chatbot.run()
    
    except KeyboardInterrupt:
        print("\n\n👋 Exiting...")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()