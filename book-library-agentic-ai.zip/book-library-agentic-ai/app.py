"""
📚 Library Management Chatbot UI
Complete version with Book Return and Employee Search
"""

import streamlit as st
import requests
import pandas as pd
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="📚 Library AI Chatbot",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 0.8rem;
        text-align: center;
    }
    .success-box {
        background: #d4edda;
        padding: 1rem;
        border-radius: 0.5rem;
        color: #155724;
        border-left: 4px solid #28a745;
    }
    .error-box {
        background: #f8d7da;
        padding: 1rem;
        border-radius: 0.5rem;
        color: #721c24;
        border-left: 4px solid #f5c6cb;
    }
</style>
""", unsafe_allow_html=True)

# API Configuration
API_BASE_URL = "http://localhost:5000"

import re

# ==================== CHATBOT: intent parsing & handlers ====================

BOOK_ID_RE = re.compile(r'\b(B\d{2,})\b', re.IGNORECASE)
EMP_ID_RE = re.compile(r'\b(EMP\d+)\b', re.IGNORECASE)


def _text(msg):
    return {"kind": "text", "text": msg}


def _df(dataframe):
    return {"kind": "dataframe", "df": dataframe}


def chat_show_dashboard():
    try:
        r = requests.get(f"{API_BASE_URL}/api/stats/dashboard", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, I couldn't load the dashboard right now.")]
        data = r.json().get('data', {})
        summary = data.get('summary', {})
        alerts = data.get('alerts', {})
        msg = (
            f"📊 **Dashboard Summary**\n\n"
            f"- 📚 Total Books: **{summary.get('total_books', 0)}**\n"
            f"- 📖 Available: **{summary.get('available_books', 0)}**\n"
            f"- 🔄 Borrowed: **{summary.get('borrowed_books', 0)}**\n"
            f"- 👥 Employees: **{summary.get('total_employees', 0)}**\n"
            f"- 🔴 Overdue: **{alerts.get('overdue_books', 0)}**\n"
            f"- 🟡 Due Soon: **{alerts.get('due_soon', 0)}**"
        )
        return [_text(msg)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_show_overdue():
    try:
        r = requests.get(f"{API_BASE_URL}/api/borrowed/overdue", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, I couldn't load overdue books.")]
        overdue = r.json().get('data', [])
        if not overdue:
            return [_text("✅ No overdue books right now!")]
        df = pd.DataFrame([{
            "Title": b['book_title'],
            "Borrower": b['employee_name'],
            "Due Date": b['due_date'],
            "Days Overdue": b['days_overdue']
        } for b in overdue])
        return [_text(f"🔴 Found **{len(overdue)}** overdue book(s):"), _df(df)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_show_borrowed():
    try:
        r = requests.get(f"{API_BASE_URL}/api/borrowed", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, I couldn't load borrowed books.")]
        borrowed = r.json().get('data', [])
        if not borrowed:
            return [_text("✅ No books are currently borrowed!")]
        df = pd.DataFrame([{
            "Title": b['title'],
            "Borrower": b['employee_name'],
            "Due Date": b['due_date'],
            "Status": b['due_status']
        } for b in borrowed])
        return [_text(f"📖 **{len(borrowed)}** book(s) currently borrowed:"), _df(df)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_show_employees():
    try:
        r = requests.get(f"{API_BASE_URL}/api/employees", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, I couldn't load employees.")]
        employees = r.json().get('data', [])
        if not employees:
            return [_text("No employees found.")]
        df = pd.DataFrame([{
            "Employee ID": e['employee_id'],
            "Name": e['name'],
            "Department": e['department'],
            "Email": e['email']
        } for e in employees])
        return [_text(f"👥 **{len(employees)}** employee(s):"), _df(df)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_available_books():
    """List books that currently have at least one available copy."""
    try:
        r = requests.get(f"{API_BASE_URL}/api/books/available", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, I couldn't load available books right now.")]
        available = r.json().get('data', [])
        if not available:
            return [_text("📚 No books are currently available — everything is checked out!")]
        df = pd.DataFrame([{
            "Title": b['title'],
            "Author": b['author'],
            "Genre": b.get('genre', 'N/A'),
            "Available Copies": b['available_copies'],
            "Total Copies": b['total_copies']
        } for b in available])
        return [_text(f"📚 **{len(available)}** book(s) currently available to borrow:"), _df(df)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_search_books(query):
    if not query:
        return [_text("What book should I search for? Try: *search python*")]
    try:
        r = requests.get(f"{API_BASE_URL}/api/books/search?q={query}", timeout=5)
        if r.status_code != 200:
            return [_text("❌ Sorry, the search failed.")]
        results = r.json().get('data', [])
        if not results:
            return [_text(f"No books found for **'{query}'**.")]
        df = pd.DataFrame([{
            "Title": b['title'],
            "Author": b['author'],
            "Genre": b['genre'],
            "Available": b['available_copies'],
            "Total": b['total_copies']
        } for b in results])
        return [_text(f"🔍 Found **{len(results)}** book(s) for '{query}':"), _df(df)]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_borrow_book(book_id, emp_id):
    if not book_id or not emp_id:
        return [_text("To borrow, tell me both a book ID and employee ID, e.g. "
                       "*borrow B001 for EMP001*")]
    try:
        r = requests.post(
            f"{API_BASE_URL}/api/borrow",
            json={"employee_id": emp_id, "book_id": book_id, "due_days": 14},
            timeout=5
        )
        if r.status_code == 200:
            result = r.json()
            if result.get('status') == 'success':
                return [_text(f"✅ {result.get('message', 'Book borrowed successfully!')}")]
            return [_text(f"❌ {result.get('message', 'Failed to borrow book.')}")]
        return [_text("❌ Failed to process the borrow request.")]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_return_book(book_id, emp_id):
    if not book_id or not emp_id:
        return [_text("To return a book, tell me both a book ID and employee ID, e.g. "
                       "*return B001 EMP001*")]
    try:
        r = requests.post(
            f"{API_BASE_URL}/api/return",
            json={"employee_id": emp_id, "book_id": book_id},
            timeout=5
        )
        if r.status_code == 200:
            result = r.json()
            if result.get('status') == 'success':
                return [_text(f"✅ {result.get('message', 'Book returned successfully!')}")]
            return [_text(f"❌ {result.get('message', 'Failed to return book.')}")]
        return [_text("❌ Failed to process the return request.")]
    except Exception as e:
        return [_text(f"❌ Error: {str(e)}")]


def chat_help():
    return [_text(
        "Here's what I can help with:\n\n"
        "- **show dashboard** — overall library stats\n"
        "- **what's overdue?** — list overdue books\n"
        "- **currently borrowed** — list borrowed books\n"
        "- **available books** — list books that can still be borrowed\n"
        "- **search <keyword>** — search books by title/genre/author\n"
        "- **borrow <BOOK_ID> for <EMP_ID>** — borrow a book\n"
        "- **return <BOOK_ID> <EMP_ID>** — return a book\n"
        "- **list employees** — show all employees"
    )]


def _has_word(word, text):
    """Word-boundary match so e.g. 'borrow' doesn't also match inside 'borrowed'."""
    return re.search(rf'\b{re.escape(word)}\b', text) is not None


def process_chat_message(raw_text):
    """Rule-based intent matcher: routes a user message to the right API call."""
    text = raw_text.strip()
    lower = text.lower()

    book_id_match = BOOK_ID_RE.search(text)
    emp_id_match = EMP_ID_RE.search(text)
    book_id = book_id_match.group(1).upper() if book_id_match else None
    emp_id = emp_id_match.group(1).upper() if emp_id_match else None

    if any(_has_word(g, lower) for g in ["hello", "hi", "hey"]) and len(lower.split()) <= 3:
        return [_text("👋 Hello! Ask me about books, borrowing, returns, or employees. "
                       "Type **help** to see everything I can do.")]

    if "help" in lower or "what can you do" in lower or "commands" in lower:
        return chat_help()

    # Check listing intents ("borrowed", "available") BEFORE the action verbs
    # ("borrow", "return") so phrases like "currently borrowed books" or
    # "what books are available" aren't mistaken for an action request.
    if "borrowed" in lower or "checked out" in lower or "checked-out" in lower:
        return chat_show_borrowed()

    if _has_word("available", lower) or "in stock" in lower or "not borrowed" in lower:
        return chat_available_books()

    if _has_word("overdue", lower) or _has_word("late", lower):
        return chat_show_overdue()

    if any(_has_word(w, lower) for w in ["dashboard", "stats", "statistics", "summary"]):
        return chat_show_dashboard()

    if any(_has_word(w, lower) for w in ["employee", "employees", "staff"]):
        return chat_show_employees()

    if _has_word("borrow", lower):
        return chat_borrow_book(book_id, emp_id)

    if _has_word("return", lower):
        return chat_return_book(book_id, emp_id)

    if any(_has_word(w, lower) for w in ["search", "find"]) or "look for" in lower:
        query = lower
        for kw in ["search for", "search", "look for", "find"]:
            query = query.replace(kw, "")
        return chat_search_books(query.strip())

    # Fallback: try treating the whole message as a book search
    return chat_search_books(text) + [
        _text("_(If that's not what you meant, type **help** to see available commands.)_")
    ]


# Initialize session state
if 'connected' not in st.session_state:
    st.session_state.connected = False

if 'refresh_key' not in st.session_state:
    st.session_state.refresh_key = 0

if 'chat_history' not in st.session_state:
    st.session_state.chat_history = [
        {
            "role": "assistant",
            "blocks": [
                {"kind": "text", "text": "👋 Hi! I'm your Library Assistant. Ask me things like:\n"
                                          "- *show dashboard*\n"
                                          "- *what's overdue?*\n"
                                          "- *currently borrowed books*\n"
                                          "- *available books*\n"
                                          "- *search python*\n"
                                          "- *borrow B001 for EMP001*\n"
                                          "- *return B001 EMP001*\n"
                                          "- *list employees*\n\n"
                                          "Type **help** any time to see this again."}
            ]
        }
    ]

# Sidebar
with st.sidebar:
    st.title("⚙️ Configuration")
    
    # Check API connection
    if st.button("🔗 Test Connection", use_container_width=True):
        try:
            response = requests.get(f"{API_BASE_URL}/api/health", timeout=2)
            if response.status_code == 200:
                st.session_state.connected = True
                st.success("✓ Connected to API Server!")
            else:
                st.error("API Server Error")
        except Exception as e:
            st.error("Cannot connect to API Server")
            st.info("Make sure to run: python api_main.py")
    
    st.divider()
    
    # Status indicator
    if st.session_state.connected:
        st.success("✓ API Connected")
    else:
        st.warning("⚠️ Not Connected - Click test button above")
    
    st.divider()
    
    st.markdown("""
    ### 📖 About This App
    
    Library Management System with:
    - 📊 Dashboard
    - 📖 Borrowed Books Tracker
    - ⏰ Overdue Alerts
    - 🔍 Book Search & Borrow
    - 👥 Employee Management
    - 📤 Book Return
    - 🔎 Employee Search
    """)

# Main Title
st.title("📚 Library Management System")

# If not connected, show warning
if not st.session_state.connected:
    st.warning("🔌 Click 'Test Connection' in sidebar to connect to API Server")
    st.info("Make sure API server is running: `python api_main.py`")
    st.stop()

# Create tabs
tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "📊 Dashboard",
    "📖 Borrowed Books",
    "⏰ Overdue",
    "🔍 Search Books",
    "📤 Return Book",
    "👥 Employees",
    "🤖 Chatbot"
])

# ==================== TAB 1: Dashboard ====================
with tab1:
    st.header("📊 Dashboard")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/stats/dashboard", timeout=5)
        
        if response.status_code == 200:
            stats = response.json()
            data = stats.get('data', {})
            summary = data.get('summary', {})
            alerts = data.get('alerts', {})
            
            # Statistics Cards
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric(
                    "📚 Total Books",
                    summary.get('total_books', 0),
                    help="Total books in library"
                )
            
            with col2:
                st.metric(
                    "📖 Available",
                    summary.get('available_books', 0),
                    help="Books available to borrow"
                )
            
            with col3:
                st.metric(
                    "🔄 Borrowed",
                    summary.get('borrowed_books', 0),
                    help="Currently borrowed books"
                )
            
            with col4:
                st.metric(
                    "👥 Employees",
                    summary.get('total_employees', 0),
                    help="Total employees"
                )
            
            st.divider()
            
            # Alerts
            col1, col2 = st.columns(2)
            
            with col1:
                overdue_count = alerts.get('overdue_books', 0)
                if overdue_count > 0:
                    st.error(f"🔴 **Overdue Books: {overdue_count}**")
                else:
                    st.success("✓ No overdue books!")
            
            with col2:
                due_soon_count = alerts.get('due_soon', 0)
                if due_soon_count > 0:
                    st.warning(f"🟡 **Due Soon: {due_soon_count}**")
                else:
                    st.success("✓ No books due soon!")
            
            st.divider()
            
            # Top Books
            if 'top_books' in data and data['top_books']:
                st.subheader("📈 Top Borrowed Books")
                top_books = data['top_books']
                
                chart_data = pd.DataFrame(
                    [{"Title": b['title'][:20], "Count": b['borrow_count']} for b in top_books]
                )
                
                st.bar_chart(chart_data.set_index("Title"), height=400)
            
            # Top Borrowers
            if 'top_borrowers' in data and data['top_borrowers']:
                st.subheader("👥 Top Borrowers")
                top_borrowers = data['top_borrowers']
                
                borrower_data = pd.DataFrame(
                    [{"Name": b['name'], "Books": b['borrow_count']} for b in top_borrowers]
                )
                
                st.bar_chart(borrower_data.set_index("Name"), height=300)
        
        else:
            st.error("Failed to load dashboard")
    
    except Exception as e:
        st.error(f"Error loading dashboard: {str(e)}")

# ==================== TAB 2: Borrowed Books ====================
with tab2:
    st.header("📖 Currently Borrowed Books")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/borrowed", timeout=5)
        
        if response.status_code == 200:
            borrowed = response.json().get('data', [])
            
            if borrowed:
                # Create dataframe
                df_data = []
                for book in borrowed:
                    df_data.append({
			"📖 Book Id": book['book_id'],
                        "📖 Title": book['title'],
                        "👤 Borrower": book['employee_name'],
                        "📅 Borrow Date": book['borrow_date'],
                        "📅 Due Date": book['due_date'],
                        "📊 Status": book['due_status'],
                        "⏱️ Days Left": book['days_remaining']
                    })
                
                df = pd.DataFrame(df_data)
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                st.divider()
                
                # Detailed view
                st.subheader("📋 Detailed View")
                
                for book in borrowed:
                    status_color = "🔴" if book['due_status'] == 'overdue' else "🟡" if book['due_status'] == 'due_soon' else "🟢"
                    
                    with st.expander(f"{status_color} {book['title']} - {book['employee_name']}"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write(f"**Author:** {book['author']}")
                            st.write(f"**Genre:** {book['genre']}")
                            st.write(f"**ISBN:** {book['isbn']}")
                        
                        with col2:
                            st.write(f"**Borrow Date:** {book['borrow_date']}")
                            st.write(f"**Due Date:** {book['due_date']}")
                            st.write(f"**Email:** {book['email']}")
                            st.write(f"**Department:** {book.get('department', 'N/A')}")
                        
                        if book['due_status'] == 'overdue':
                            st.error(f"🔴 Overdue by {abs(book['days_remaining'])} days")
                        elif book['due_status'] == 'due_soon':
                            st.warning(f"🟡 Due in {book['days_remaining']} days")
                        else:
                            st.success(f"🟢 {book['days_remaining']} days remaining")
            
            else:
                st.success("✅ No books currently borrowed!")
        
        else:
            st.error("Failed to load borrowed books")
    
    except Exception as e:
        st.error(f"Error: {str(e)}")

# ==================== TAB 3: Overdue ====================
with tab3:
    st.header("⏰ Overdue Books")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/borrowed/overdue", timeout=5)
        
        if response.status_code == 200:
            overdue = response.json().get('data', [])
            
            if overdue:
                st.error(f"🔴 **{len(overdue)} Overdue Book(s)**")
                st.divider()
                
                for book in overdue:
                    col1, col2, col3 = st.columns([2, 1, 1])
                    
                    with col1:
                        st.write(f"### 📖 {book['book_title']}")
                        st.write(f"**Borrower:** {book['employee_name']}")
                        st.write(f"**Email:** {book['email']}")
                        st.write(f"**Due Date:** {book['due_date']}")
                    
                    with col2:
                        urgency = book['days_overdue']
                        if urgency > 7:
                            st.error(f"🔴 CRITICAL\n{urgency} days")
                        elif urgency > 3:
                            st.warning(f"🟠 HIGH\n{urgency} days")
                        else:
                            st.info(f"🟡 MEDIUM\n{urgency} days")
                    
                    with col3:
                        if st.button("📧 Send", key=f"remind_{book['book_title']}"):
                            st.success(f"✓ Reminder sent!")
                    
                    st.divider()
            
            else:
                st.success("✅ No overdue books!")
        
        else:
            st.error("Failed to load overdue books")
    
    except Exception as e:
        st.error(f"Error: {str(e)}")

# ==================== TAB 4: Search Books ====================
with tab4:
    st.header("🔍 Search & Borrow Books")
    
    search_query = st.text_input(
        "Search for books:",
        placeholder="e.g., Python, Design Patterns...",
        key="search_books"
    )
    
    if search_query:
        try:
            response = requests.get(
                f"{API_BASE_URL}/api/books/search?q={search_query}",
                timeout=5
            )
            
            if response.status_code == 200:
                results = response.json().get('data', [])
                
                if results:
                    st.success(f"Found {len(results)} book(s)")
                    st.divider()
                    
                    for book in results:
                        with st.expander(f"📖 {book['title']}"):
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.write(f"**Author:** {book['author']}")
                                st.write(f"**Genre:** {book['genre']}")
                                st.write(f"**ISBN:** {book['isbn']}")
                                st.write(f"**Provider:** {book.get('provider_id', 'N/A')}")
                            
                            with col2:
                                st.metric("Available Copies", book['available_copies'])
                                st.metric("Total Copies", book['total_copies'])
                            
                            st.divider()
                            
                            # Borrow section
                            st.subheader("🔄 Borrow This Book")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                emp_id = st.text_input(
                                    "Employee ID:",
                                    key=f"emp_borrow_{book['book_id']}",
                                    placeholder="e.g., EMP001"
                                ).upper()
                            
                            with col2:
                                due_days = st.number_input(
                                    "Borrow Duration (days):",
                                    min_value=1,
                                    max_value=30,
                                    value=14,
                                    key=f"days_{book['book_id']}"
                                )
                            
                            if st.button("✅ Borrow Book", key=f"borrow_{book['book_id']}", use_container_width=True):
                                if emp_id:
                                    try:
                                        borrow_response = requests.post(
                                            f"{API_BASE_URL}/api/borrow",
                                            json={
                                                "employee_id": emp_id,
                                                "book_id": book['book_id'],
                                                "due_days": int(due_days)
                                            },
                                            timeout=5
                                        )
                                        if borrow_response.status_code == 200:
                                            result = borrow_response.json()
                                            if result.get('status') == 'success':
                                                st.success(f"✓ {result.get('message', 'Book borrowed successfully!')}")
                                            else:
                                                st.error(f"✗ {result.get('message', 'Failed to borrow')}")
                                        else:
                                            st.error("Failed to borrow book")
                                    except Exception as e:
                                        st.error(f"Error: {str(e)}")
                                else:
                                    st.error("❌ Please enter employee ID")
                
                else:
                    st.info(f"No books found for '{search_query}'")
            
            else:
                st.error("Failed to search books")
        
        except Exception as e:
            st.error(f"Error: {str(e)}")

# ==================== TAB 5: Return Book ====================
with tab5:
    st.header("📤 Return Book")
    
    st.markdown("""
    Use this section to return a borrowed book back to the library.
    """)
    
    col1, col2 = st.columns(2)
    
    with col1:
        emp_id_return = st.text_input(
            "Employee ID:",
            placeholder="e.g., EMP001",
            key="emp_return"
        ).upper()
    
    with col2:
        book_id_return = st.text_input(
            "Book ID:",
            placeholder="e.g., B001",
            key="book_return"
        ).upper()
    
    if st.button("📤 Return Book", use_container_width=True, key="btn_return"):
        if emp_id_return and book_id_return:
            try:
                response = requests.post(
                    f"{API_BASE_URL}/api/return",
                    json={
                        "employee_id": emp_id_return,
                        "book_id": book_id_return
                    },
                    timeout=5
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get('status') == 'success':
                        st.success(f"✅ {result.get('message', 'Book returned successfully!')}")
                        st.balloons()
                    else:
                        st.error(f"❌ {result.get('message', 'Failed to return book')}")
                else:
                    st.error("Failed to process return")
            
            except Exception as e:
                st.error(f"Error: {str(e)}")
        else:
            st.error("❌ Please enter both Employee ID and Book ID")
    
    st.divider()
    
    # Show current borrowed books
    st.subheader("📋 Current Borrowed Books")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/borrowed", timeout=5)
        
        if response.status_code == 200:
            borrowed = response.json().get('data', [])
            
            if borrowed:
                df_data = []
                for book in borrowed:
                    df_data.append({
                        "Book ID": book['book_id'],
                        "Title": book['title'],
                        "Employee ID": book['employee_id'],
                        "Borrower": book['employee_name'],
                        "Due Date": book['due_date']
                    })
                
                df = pd.DataFrame(df_data)
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.success("No books currently borrowed!")
        
        else:
            st.error("Failed to load borrowed books")
    
    except Exception as e:
        st.error(f"Error: {str(e)}")

# ==================== TAB 6: All Employees ====================
with tab6:
    st.header("👥 All Employees")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/employees", timeout=5)
        
        if response.status_code == 200:
            employees = response.json().get('data', [])
            
            if employees:
                # Create dataframe
                df_data = []
                for emp in employees:
                    df_data.append({
                        "Employee ID": emp['employee_id'],
                        "Name": emp['name'],
                        "Department": emp['department'],
                        "Email": emp['email'],
                        "Phone": emp['phone'],
                        "Joining Date": emp['joining_date']
                    })
                
                df = pd.DataFrame(df_data)
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                st.divider()
                
                # Employee details expander
                st.subheader("📋 Employee Details")
                
                for emp in employees:
                    with st.expander(f"👤 {emp['name']} ({emp['employee_id']})"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write(f"**Name:** {emp['name']}")
                            st.write(f"**Employee ID:** {emp['employee_id']}")
                            st.write(f"**Department:** {emp['department']}")
                        
                        with col2:
                            st.write(f"**Email:** {emp['email']}")
                            st.write(f"**Phone:** {emp['phone']}")
                            st.write(f"**Joining Date:** {emp['joining_date']}")
            
            else:
                st.info("No employees found")
        
        else:
            st.error("Failed to load employees")
    
    except Exception as e:
        st.error(f"Error: {str(e)}")

# ==================== TAB 7: Chatbot ====================
with tab7:
    st.header("🤖 Library Assistant")
    st.caption("A rule-based helper — it matches keywords in your message to the library API. No AI/API key required.")

    col_clear, _ = st.columns([1, 5])
    with col_clear:
        if st.button("🗑️ Clear Chat", use_container_width=True):
            st.session_state.chat_history = st.session_state.chat_history[:1]
            st.rerun()

    # Render chat history
    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            for block in msg["blocks"]:
                if block["kind"] == "text":
                    st.markdown(block["text"])
                elif block["kind"] == "dataframe":
                    st.dataframe(block["df"], use_container_width=True, hide_index=True)

    # Chat input
    user_msg = st.chat_input("Ask about books, borrowing, returns, or employees...")

    if user_msg:
        st.session_state.chat_history.append({"role": "user", "blocks": [_text(user_msg)]})
        blocks = process_chat_message(user_msg)
        st.session_state.chat_history.append({"role": "assistant", "blocks": blocks})
        st.rerun()

# Footer
st.divider()
st.markdown("""
---
**📚 Library Management System**
- API Server: `http://localhost:5000`
- Chatbot UI: `http://localhost:8501`
- Developed with Streamlit
""")